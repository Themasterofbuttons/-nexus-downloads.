#!/usr/bin/env python3
"""NEXUS Launcher: version selection and opt-in client updates for NEXUS."""
from __future__ import annotations

import hashlib
import getpass
import json
import os
import platform
import re
import shutil
import subprocess
import sys
import tarfile
import tempfile
import threading
import time
import urllib.parse
import urllib.request
from pathlib import Path, PurePosixPath

import gi

gi.require_version('Gtk', '3.0')
gi.require_version('Gdk', '3.0')
from gi.repository import Gdk, GLib, Gtk

APP_ID = 'ro.nexus.NexusLauncher'
APP_ROOT = Path(__file__).resolve().parent
APP_DATA = Path(os.environ.get('XDG_DATA_HOME') or (Path.home() / '.local/share')) / 'nexus-launcher'
VERSIONS_DIR = APP_DATA / 'versions'
CONFIG_PATH = APP_DATA / 'settings.json'
MAX_CATALOG_BYTES = 1024 * 1024
MAX_PACKAGE_BYTES = 600 * 1024 * 1024
MAX_EXTRACTED_BYTES = 1536 * 1024 * 1024
MAX_ARCHIVE_FILES = 30000
VERSION_RE = re.compile(r'^[0-9]+\.[0-9]+\.[0-9]+(?:[-+][A-Za-z0-9.-]+)?$')

CSS = b'''
window, .background { background: #030719; color: #eaf4ff; }
headerbar { min-height: 50px; color: #eaf4ff; background-image: linear-gradient(to bottom, #050c22, #030719); border-bottom: 1px solid #15305f; box-shadow: 0 4px 20px rgba(0, 0, 15, .5); }
headerbar .title { color: #e8f5ff; font-weight: 700; letter-spacing: 5px; }
headerbar .subtitle { color: #7188b3; font-size: 9px; letter-spacing: 1px; }
headerbar button { color: #9fc3ff; background: transparent; border: 1px solid transparent; border-radius: 8px; }
headerbar button:hover { color: #fff; background: #101b3d; border-color: #3357a4; }
.launcher-shell { background: #030719; }
.launcher-sidebar { background-image: linear-gradient(to bottom, #050a20, #030719 82%); border-right: 1px solid #162752; padding: 15px 13px; }
.brand { color: #eaf5ff; font: 800 22px 'DejaVu Sans'; letter-spacing: 5px; }
.brand-sub { color: #7696c5; font-size: 8px; letter-spacing: 2px; }
.brand-line { background: #152752; min-height: 1px; }
.launcher-nav button { color: #a4badc; background: transparent; border: 1px solid transparent; border-radius: 10px; padding: 12px 11px; font-size: 12px; }
.launcher-nav button:hover { color: #f4fbff; background: #0d1633; border-color: #243b78; }
.launcher-nav button.active { color: #fff; background-image: linear-gradient(100deg, #5524cb, #151b59 78%); border-color: #a158ff; box-shadow: 0 0 19px rgba(91, 40, 255, .47), inset 3px 0 #63eaff; }
.page { padding: 14px; }
.home-layout { padding: 0; }
.card { background-image: linear-gradient(145deg, rgba(7, 17, 43, .97), rgba(4, 10, 29, .98) 72%); border: 1px solid #253e89; border-radius: 12px; padding: 13px; box-shadow: 0 9px 24px rgba(0, 0, 15, .37), inset 0 1px rgba(175, 210, 255, .035); }
.card:hover { border-color: #426be1; }
.card-title { color: #83baff; font-size: 9px; font-weight: 700; letter-spacing: 1.2px; }
.card-copy { color: #a9c1e5; font-size: 10px; }
.muted { color: #7f96b7; font-size: 9px; }
.good { color: #30e5c3; font-size: 10px; font-weight: 700; }
.warning { color: #ffd27c; font-size: 10px; }
.version-large { color: #f0f6ff; font: 600 21px 'DejaVu Sans'; }
.hero { border: 1px solid #3063e1; border-radius: 14px; background-image: linear-gradient(115deg, #081a42, #091134 50%, #171044); box-shadow: 0 0 25px rgba(40, 91, 255, .18), inset 0 1px rgba(175, 210, 255, .08); min-height: 305px; }
.hero-content { padding: 21px 24px 18px; }
.hero-kicker { color: #8ebcff; font-size: 9px; letter-spacing: 3px; }
.hero-word { color: #f7faff; font: 700 35px 'DejaVu Sans'; letter-spacing: 9px; }
.hero-title { color: #f2f7ff; font: 700 28px 'DejaVu Sans'; letter-spacing: 1px; }
.hero-tagline { color: #91c7ff; font-size: 10px; letter-spacing: 4px; }
.hero-copy { color: #c2d8ef; font-size: 11px; }
button.primary { color: #fff; background-image: linear-gradient(110deg, #6824ef, #165cf4 58%, #0da8f3); border: 1px solid #6fdbff; border-radius: 9px; padding: 10px 17px; font-weight: 700; box-shadow: 0 5px 20px rgba(39, 100, 255, .44); }
button.primary:hover { background-image: linear-gradient(110deg, #8c3cff, #1878ff 58%, #13c4f6); box-shadow: 0 7px 25px rgba(61, 111, 255, .6); }
button.primary:disabled { color: #8ba2c2; background: #17213c; border-color: #32446d; box-shadow: none; }
button.launch-cta { font-size: 14px; padding: 12px 24px; border-radius: 9px; }
button.secondary { color: #bad4ff; background: #0a1533; border: 1px solid #344c8e; border-radius: 8px; padding: 8px 12px; }
button.secondary:hover { color: white; border-color: #62a8ff; background: #101f49; }
button.quick-action { color: #c8dcff; background-image: linear-gradient(to bottom, #0d1836, #081127); border: 1px solid #1c2e61; border-radius: 8px; padding: 8px 10px; font-size: 10px; }
button.quick-action:hover { color: white; border-color: #3a5ab4; background: #111f46; }
combobox button, entry { color: #e0edff; background: #08132d; border: 1px solid #2c4787; border-radius: 7px; padding: 6px; }
entry:focus, combobox button:focus, button:focus { border-color: #61bfff; box-shadow: 0 0 0 2px rgba(53, 131, 255, .2); }
progress trough { background: #142447; border-radius: 8px; min-height: 7px; }
progress progress { background-image: linear-gradient(to right, #327aff, #b241ff); border-radius: 8px; min-height: 7px; }
separator { background: #1b2d59; }
.release-notes { color: #bed0e9; font-size: 10px; }
.release-heading { color: #eff6ff; font-size: 13px; font-weight: 700; }
.release-version { color: #58cfff; font: 500 10px 'DejaVu Sans Mono'; }
.release-art { background-image: linear-gradient(135deg, #071b53, #1c1354 55%, #081a39); border: 1px solid #315de2; border-radius: 9px; padding: 9px; box-shadow: inset 0 0 28px rgba(30, 108, 255, .19); }
.profile-avatar { color: #eafbff; font: 700 24px 'DejaVu Sans'; background-image: linear-gradient(135deg, #082b75, #6418b9); border: 1px solid #4697ff; border-radius: 28px; padding: 12px; }
.profile-name { color: #ecf5ff; font-size: 13px; font-weight: 700; }
.profile-value { color: #c2d8ff; font-size: 9px; }
.system-value { color: #9dc0f3; font-size: 9px; }
.footer { color: #6c83a5; font-size: 8px; }
.footer-brand { color: #7596c4; font-size: 8px; letter-spacing: 2px; }
'''


def label(text='', style=None, xalign=0):
    widget = Gtk.Label(label=text, xalign=xalign)
    widget.set_line_wrap(True)
    widget.set_selectable(True)
    if style:
        widget.get_style_context().add_class(style)
    return widget


def card(title):
    box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=10)
    box.get_style_context().add_class('card')
    box.pack_start(label(title, 'card-title'), False, False, 0)
    return box


def read_json(path, fallback):
    try:
        value = json.loads(path.read_text(encoding='utf-8'))
        return value
    except (OSError, ValueError, TypeError):
        return fallback


def app_version(path):
    data = read_json(path / 'nexus-version.json', {})
    value = data.get('version') if isinstance(data, dict) else None
    return value if isinstance(value, str) and VERSION_RE.fullmatch(value) else 'local'


def version_key(version):
    match = re.match(r'^(\d+)\.(\d+)\.(\d+)(?:-([A-Za-z0-9.-]+))?(?:\+([A-Za-z0-9.-]+))?$', version)
    if not match:
        return (0, 0, 0, 0, ())
    major, minor, patch, prerelease, _build = match.groups()
    if prerelease is None:
        return (int(major), int(minor), int(patch), 1, ())
    parts = tuple((0, int(part)) if part.isdigit() else (1, part.lower()) for part in prerelease.split('.'))
    return (int(major), int(minor), int(patch), 0, parts)


class NexusLauncherWindow(Gtk.ApplicationWindow):
    def __init__(self, app):
        super().__init__(application=app, title='NEXUS Launcher')
        self.set_default_size(1510, 930)
        self.set_size_request(1040, 700)
        self.set_position(Gtk.WindowPosition.CENTER)
        self.started_at = time.monotonic()
        icon_path = APP_ROOT / 'static' / 'nexus-launcher.svg'
        if icon_path.is_file():
            try:
                self.set_icon_from_file(str(icon_path))
            except GLib.Error:
                self.set_icon_name('applications-system')
        else:
            self.set_icon_name('applications-system')
        self.catalog = []
        self.latest = None
        self.busy = False
        self.config = self.load_config()
        self.local_project = self.detect_local_project()
        self.installed = self.scan_installed()
        self.choices = []
        self.selectors = []
        self.nav_buttons = {}

        provider = Gtk.CssProvider()
        provider.load_from_data(CSS)
        screen = Gdk.Screen.get_default()
        if screen:
            Gtk.StyleContext.add_provider_for_screen(screen, provider, Gtk.STYLE_PROVIDER_PRIORITY_APPLICATION)

        header = Gtk.HeaderBar()
        header.set_show_close_button(True)
        header.props.title = 'N E X U S'
        header.props.subtitle = 'YOUR SYSTEM. YOUR CONTROL.'
        self.set_titlebar(header)
        self.header_status = label('LOCAL MODE', 'good')
        header.pack_end(self.header_status)
        minimize_button = Gtk.Button(label='—')
        minimize_button.set_tooltip_text('Minimize')
        minimize_button.connect('clicked', lambda *_: self.iconify())
        header.pack_end(minimize_button)
        settings_button = Gtk.Button(label='⚙')
        settings_button.set_tooltip_text('Settings')
        settings_button.connect('clicked', lambda *_: self.navigate('settings'))
        header.pack_end(settings_button)

        shell = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=0)
        shell.get_style_context().add_class('launcher-shell')
        self.add(shell)
        sidebar = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=8)
        sidebar.set_size_request(218, -1)
        sidebar.get_style_context().add_class('launcher-sidebar')
        shell.pack_start(sidebar, False, False, 0)
        self.build_sidebar(sidebar)

        self.stack = Gtk.Stack(transition_type=Gtk.StackTransitionType.CROSSFADE, transition_duration=160)
        self.stack.set_hexpand(True)
        self.stack.set_vexpand(True)
        shell.pack_start(self.stack, True, True, 0)
        self.build_home()
        self.build_versions()
        self.build_settings()
        self.build_logs()
        self.build_about()
        self.update_installed_summary()
        self.populate_version_selectors()
        self.navigate('home')
        self.update_selection()
        self.set_status('Choose a version or check for updates.', 'muted')
        self.refresh_system_info()
        GLib.timeout_add_seconds(15, self.refresh_system_info)
        GLib.timeout_add_seconds(30, self.refresh_session_time)
        if self.config.get('catalog_url'):
            self.check_catalog(silent=True)

    def load_config(self):
        config = read_json(CONFIG_PATH, {})
        if not isinstance(config, dict):
            config = {}
        source_config = read_json(APP_ROOT / 'launcher_config.json', {})
        configured_url = config.get('catalog_url')
        bundled_url = source_config.get('catalog_url', '') if isinstance(source_config, dict) else ''
        url = configured_url or bundled_url
        return {'catalog_url': url if isinstance(url, str) else ''}

    def detect_local_project(self):
        if (APP_ROOT / 'desktop_app.py').is_file() and (APP_ROOT / 'server.py').is_file():
            return {'version': app_version(APP_ROOT), 'path': APP_ROOT, 'label': 'Proiect local'}
        return None

    def scan_installed(self):
        installed = {}
        try:
            children = list(VERSIONS_DIR.iterdir())
        except OSError:
            return installed
        for path in children:
            if not path.is_dir() or not (path / 'desktop_app.py').is_file():
                continue
            version = app_version(path)
            if VERSION_RE.fullmatch(version):
                installed[version] = path
        return installed

    def build_sidebar(self, sidebar):
        brand = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=11)
        brand.set_margin_start(5)
        brand.set_margin_top(8)
        brand.set_margin_bottom(17)
        mark = Gtk.Image.new_from_file(str(APP_ROOT / 'static' / 'nexus-launcher.svg'))
        mark.set_pixel_size(43)
        brand.pack_start(mark, False, False, 0)
        brand_text = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=2)
        brand_text.pack_start(label('NEXUS', 'brand'), False, False, 0)
        brand_text.pack_start(label('LAUNCHER', 'brand-sub'), False, False, 0)
        brand.pack_start(brand_text, False, False, 0)
        sidebar.pack_start(brand, False, False, 0)
        tagline = label('ONE SYSTEM. YOUR CONTROL.', 'brand-sub')
        tagline.set_margin_start(6)
        tagline.set_margin_bottom(14)
        sidebar.pack_start(tagline, False, False, 0)
        divider = Gtk.Separator(orientation=Gtk.Orientation.HORIZONTAL)
        divider.get_style_context().add_class('brand-line')
        sidebar.pack_start(divider, False, False, 0)

        self.nav_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=5)
        self.nav_box.get_style_context().add_class('launcher-nav')
        for icon, title, page in [('⌂', 'Home', 'home'), ('▷', 'Play', 'versions'), ('⚙', 'Settings', 'settings'), ('▤', 'Logs', 'logs'), ('ⓘ', 'About', 'about')]:
            button = Gtk.Button(label=f'{icon}   {title}')
            button.set_relief(Gtk.ReliefStyle.NONE)
            button.connect('clicked', lambda _button, key=page: self.navigate(key))
            self.nav_box.pack_start(button, False, False, 0)
            self.nav_buttons[page] = button
        sidebar.pack_start(self.nav_box, False, False, 0)

        spacer = Gtk.Box()
        spacer.set_vexpand(True)
        sidebar.pack_start(spacer, True, True, 0)
        account = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=10)
        account.get_style_context().add_class('card')
        account_avatar = label('◉', 'profile-avatar')
        account.pack_start(account_avatar, False, False, 0)
        account_text = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=3)
        account_text.pack_start(label(getpass.getuser(), 'profile-name'), False, False, 0)
        account_text.pack_start(label('●  LOCAL ACCOUNT', 'good'), False, False, 0)
        account.pack_start(account_text, True, True, 0)
        sidebar.pack_start(account, False, False, 9)
        launcher_info = read_json(APP_ROOT / 'launcher-version.json', {})
        launcher_version = launcher_info.get('version', '—') if isinstance(launcher_info, dict) else '—'
        sidebar.pack_start(label(f'N E X U S   L A U N C H E R   {launcher_version}', 'footer-brand'), False, False, 7)
        sidebar.pack_start(label('SELECT · INSTALL · LAUNCH', 'footer'), False, False, 0)

    def page(self, key):
        scroll = Gtk.ScrolledWindow()
        scroll.set_policy(Gtk.PolicyType.NEVER, Gtk.PolicyType.AUTOMATIC)
        content = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=14)
        content.get_style_context().add_class('page')
        scroll.add(content)
        self.stack.add_named(scroll, key)
        return content

    def build_home(self):
        page = self.page('home')
        layout = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=12)
        layout.get_style_context().add_class('home-layout')
        page.pack_start(layout, True, True, 0)

        main = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=11)
        main.set_hexpand(True)
        main.set_vexpand(True)
        layout.pack_start(main, True, True, 0)
        rail = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=11)
        rail.set_size_request(280, -1)
        layout.pack_start(rail, False, False, 0)

        hero = Gtk.Overlay()
        hero.get_style_context().add_class('hero')
        hero.set_size_request(500, 310)
        art = Gtk.DrawingArea()
        art.set_hexpand(True)
        art.set_vexpand(True)
        art.connect('draw', self.draw_hero_art)
        hero.add(art)
        hero_content = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=5)
        hero_content.get_style_context().add_class('hero-content')
        hero.add_overlay(hero_content)
        hero_brand = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=13)
        hero_mark = Gtk.Image.new_from_file(str(APP_ROOT / 'static' / 'nexus-launcher.svg'))
        hero_mark.set_pixel_size(65)
        hero_mark.get_style_context().add_class('hero-brand-image')
        hero_brand.pack_start(hero_mark, False, False, 0)
        hero_name = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=2)
        hero_name.pack_start(label('N E X U S', 'hero-word'), False, False, 0)
        hero_name.pack_start(label('YOUR SYSTEM. YOUR CONTROL.', 'hero-tagline'), False, False, 0)
        hero_brand.pack_start(hero_name, False, False, 0)
        hero_content.pack_start(label('NEXUS LAUNCHER  /  VERSION CONTROL', 'hero-kicker'), False, False, 0)
        hero_content.pack_start(hero_brand, False, False, 0)
        hero_content.pack_start(label('SELECT  ·  INSTALL  ·  LAUNCH', 'hero-tagline'), False, False, 0)
        hero_spacer = Gtk.Box()
        hero_spacer.set_vexpand(True)
        hero_content.pack_start(hero_spacer, True, True, 0)
        hero_cta = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=10)
        hero_cta.set_halign(Gtk.Align.CENTER)
        self.install_button = Gtk.Button(label='▶   LAUNCH NEXUS')
        self.install_button.get_style_context().add_class('primary')
        self.install_button.get_style_context().add_class('launch-cta')
        self.install_button.connect('clicked', self.install_or_launch)
        hero_cta.pack_start(self.install_button, False, False, 0)
        hero_content.pack_start(hero_cta, False, False, 0)
        self.selected_summary = label('Select a version to install or launch.', 'hero-copy')
        self.selected_summary.set_halign(Gtk.Align.CENTER)
        hero_content.pack_start(self.selected_summary, False, False, 0)
        main.pack_start(hero, False, False, 0)

        tiles = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=10)
        version_card = card('NEXUS VERSION')
        self.home_selector = Gtk.ComboBoxText()
        self.home_selector.set_hexpand(True)
        self.home_selector.connect('changed', self.on_version_changed)
        self.selectors.append(self.home_selector)
        version_card.pack_start(self.home_selector, False, False, 0)
        version_card.set_hexpand(True)
        tiles.pack_start(version_card, True, True, 0)

        runtime = card('PYTHON RUNTIME')
        runtime.pack_start(label(f'Python {platform.python_version()}', 'version-large'), False, False, 1)
        runtime.pack_start(label(sys.executable, 'muted'), False, False, 0)
        runtime.set_hexpand(True)
        tiles.pack_start(runtime, True, True, 0)

        updates = card('CHECK FOR UPDATES')
        self.latest_label = label('—', 'version-large')
        updates.pack_start(self.latest_label, False, False, 0)
        self.latest_description = label('Catalog not connected', 'muted')
        updates.pack_start(self.latest_description, False, False, 0)
        self.check_button = Gtk.Button(label='⟳   Check for Updates')
        self.check_button.get_style_context().add_class('secondary')
        self.check_button.connect('clicked', lambda *_: self.check_catalog())
        updates.pack_start(self.check_button, False, False, 2)
        updates.set_hexpand(True)
        tiles.pack_start(updates, True, True, 0)
        main.pack_start(tiles, False, False, 0)

        news = card('LATEST NEWS  /  RELEASE NOTES')
        news.set_vexpand(True)
        self.release_title = label('No release catalog connected', 'release-heading')
        news.pack_start(self.release_title, False, False, 0)
        release_body = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=13)
        release_art = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=2)
        release_art.set_size_request(155, 115)
        release_art.get_style_context().add_class('release-art')
        release_art.set_valign(Gtk.Align.START)
        release_art.pack_start(label('N', 'hero-word'), True, True, 0)
        release_art.pack_start(label('NEXUS  /  RELEASES', 'footer'), False, False, 0)
        release_body.pack_start(release_art, False, False, 0)
        release_text = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=7)
        self.release_notes = label('Connect a release catalog in Settings to see published versions and notes here.', 'release-notes')
        self.release_notes.set_max_width_chars(76)
        self.release_notes.set_valign(Gtk.Align.START)
        release_text.pack_start(self.release_notes, True, True, 0)
        self.release_list = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=5)
        release_text.pack_start(self.release_list, False, False, 0)
        release_body.pack_start(release_text, True, True, 0)
        news.pack_start(release_body, True, True, 0)
        self.progress = Gtk.ProgressBar()
        self.progress.set_show_text(True)
        self.progress.set_text('Ready')
        news.pack_start(self.progress, False, False, 0)
        self.status = label('', 'muted')
        news.pack_start(self.status, False, False, 0)
        main.pack_start(news, True, True, 0)

        player = card('PLAYER')
        profile = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=10)
        profile.pack_start(label('N', 'profile-avatar'), False, False, 0)
        profile_text = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=3)
        profile_text.pack_start(label(getpass.getuser(), 'profile-name'), False, False, 0)
        profile_text.pack_start(label('NEXUS USER', 'muted'), False, False, 0)
        profile.pack_start(profile_text, True, True, 0)
        player.pack_start(profile, False, False, 0)
        player.pack_start(Gtk.Separator(orientation=Gtk.Orientation.HORIZONTAL), False, False, 2)
        self.player_session_label = self.add_info_row(player, '◷', 'Launcher Session', '0h 0m')
        self.player_installed_label = self.add_info_row(player, '▣', 'Installed Versions', '0')
        self.player_version_label = self.add_info_row(player, '◇', 'Selected Version', '—')
        rail.pack_start(player, False, False, 0)

        quick = card('QUICK ACTIONS')
        self.add_quick_action(quick, '▱   Open Installations', self.open_installations)
        self.add_quick_action(quick, '▤   View Logs', self.open_logs)
        self.add_quick_action(quick, '⚙   Settings', lambda: self.navigate('settings'))
        self.add_quick_action(quick, '⟳   Check for Updates', lambda: self.check_catalog())
        rail.pack_start(quick, False, False, 0)

        system = card('SYSTEM INFORMATION')
        self.system_os_label = self.add_info_row(system, '▱', 'OS', '—', 'system-value')
        self.system_python_label = self.add_info_row(system, '⌘', 'Python', platform.python_version(), 'system-value')
        self.system_total_memory_label = self.add_info_row(system, '▤', 'Total Memory', '—', 'system-value')
        self.system_free_memory_label = self.add_info_row(system, '▣', 'Available Memory', '—', 'system-value')
        self.system_ready_label = label('●  SYSTEM READY', 'good')
        self.system_ready_label.set_halign(Gtk.Align.END)
        system.pack_start(self.system_ready_label, False, False, 5)
        rail.pack_start(system, True, True, 0)
        self.update_installed_summary()

    def add_info_row(self, parent, icon, title, value, value_style='profile-value'):
        row = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=7)
        row.pack_start(label(icon, 'card-copy'), False, False, 0)
        row.pack_start(label(title, 'muted'), True, True, 0)
        value_label = label(value, value_style, xalign=1)
        value_label.set_max_width_chars(19)
        row.pack_start(value_label, False, False, 0)
        parent.pack_start(row, False, False, 1)
        return value_label

    def add_quick_action(self, parent, title, callback):
        button = Gtk.Button(label=f'{title}     ›')
        button.set_halign(Gtk.Align.FILL)
        child = button.get_child()
        if isinstance(child, Gtk.Label):
            child.set_xalign(0)
        button.get_style_context().add_class('quick-action')
        button.connect('clicked', lambda *_: callback())
        parent.pack_start(button, False, False, 1)

    @staticmethod
    def log_path():
        state_home = Path(os.environ.get('XDG_STATE_HOME') or (Path.home() / '.local/state'))
        return state_home / 'nexus-launcher' / 'launcher.log'

    def open_location(self, path):
        try:
            subprocess.Popen(['xdg-open', str(path)], start_new_session=True)
        except OSError as exc:
            self.set_status(f'Could not open {path}: {exc}', 'warning')

    def open_installations(self):
        try:
            VERSIONS_DIR.mkdir(parents=True, exist_ok=True)
        except OSError as exc:
            self.set_status(f'Could not access installed versions: {exc}', 'warning')
            return
        self.open_location(VERSIONS_DIR)

    def open_logs(self):
        path = self.log_path()
        try:
            path.parent.mkdir(parents=True, exist_ok=True)
        except OSError as exc:
            self.set_status(f'Could not access launcher logs: {exc}', 'warning')
            return
        self.open_location(path.parent)

    @staticmethod
    def memory_snapshot():
        values = {}
        try:
            for line in Path('/proc/meminfo').read_text(encoding='utf-8').splitlines():
                key, raw = line.split(':', 1)
                parts = raw.strip().split()
                if parts:
                    values[key] = int(parts[0]) * 1024
        except (OSError, ValueError):
            return None, None
        total = values.get('MemTotal')
        available = values.get('MemAvailable')
        display = lambda number: f'{number / (1024 ** 3):.1f} GB' if number is not None else 'Unavailable'
        return display(total), display(available)

    def refresh_system_info(self):
        if not hasattr(self, 'system_os_label'):
            return True
        total, available = self.memory_snapshot()
        self.system_os_label.set_text(f'{platform.system()} ({platform.machine()})')
        self.system_python_label.set_text(platform.python_version())
        self.system_total_memory_label.set_text(total or 'Unavailable')
        self.system_free_memory_label.set_text(available or 'Unavailable')
        self.system_ready_label.set_text('●  SYSTEM READY' if total and available else '●  SYSTEM INFO LIMITED')
        return True

    def refresh_session_time(self):
        if not hasattr(self, 'player_session_label'):
            return True
        elapsed_minutes = max(0, int((time.monotonic() - self.started_at) // 60))
        hours, minutes = divmod(elapsed_minutes, 60)
        self.player_session_label.set_text(f'{hours}h {minutes:02d}m')
        return True

    def draw_hero_art(self, widget, cr):
        allocation = widget.get_allocation()
        width, height = allocation.width, allocation.height
        if width < 2 or height < 2:
            return False
        cr.set_source_rgb(.018, .035, .105)
        cr.paint()
        for cx, cy, radius, color in [
            (.72, .24, .34, (.22, .12, .78, .13)),
            (.47, .59, .31, (.02, .31, .96, .11)),
            (.94, .58, .25, (.53, .08, .94, .11)),
        ]:
            cr.set_source_rgba(*color)
            cr.arc(width * cx, height * cy, height * radius, 0, 6.283)
            cr.fill()
        stars = [(.08,.15),(.18,.31),(.26,.12),(.38,.22),(.46,.08),(.55,.31),(.61,.13),(.84,.1),(.91,.23),(.33,.43),(.73,.39),(.12,.49),(.88,.45),(.52,.51)]
        cr.set_source_rgba(.66, .85, 1, .76)
        for index, (x, y) in enumerate(stars):
            cr.arc(width * x, height * y, 1.1 if index % 3 else 1.8, 0, 6.283)
            cr.fill()
        cr.set_source_rgba(.38, .23, .93, .3)
        cr.arc(width * .76, height * .22, height * .2, 0, 6.283)
        cr.fill()
        cr.set_source_rgba(.35, .48, 1, .55)
        cr.set_line_width(1.2)
        cr.arc(width * .76, height * .22, height * .2, 3.3, 5.8)
        cr.stroke()
        skyline = [(.48,.67,.035),(.54,.56,.024),(.59,.63,.031),(.66,.42,.022),(.7,.58,.028),(.78,.49,.035),(.84,.62,.025),(.9,.55,.033),(.96,.64,.027)]
        for index, (x, top, span) in enumerate(skyline):
            left, right = width * x, width * (x + span)
            cr.set_source_rgba(.025, .055, .17, .96)
            cr.rectangle(left, height * top, right-left, height * .39)
            cr.fill()
            cr.set_source_rgba(.16, .5, 1, .63 if index % 2 else .8)
            cr.set_line_width(1.1)
            cr.move_to(left, height * top)
            cr.line_to((left+right)/2, height * (top-.035))
            cr.line_to(right, height * top)
            cr.stroke()
            for row in range(3):
                cr.set_source_rgba(.17, .75, 1, .38)
                cr.rectangle(left + 3, height * (top + .035 + row*.045), max(2, right-left-6), 1)
                cr.fill()
        for points, color in [
            ([(0,.82),(.12,.68),(.23,.78),(.34,.7),(.47,.83),(.61,.72),(.75,.8),(.88,.69),(1,.79),(1,1),(0,1)], (.018,.045,.13,.98)),
            ([(0,.91),(.17,.8),(.31,.89),(.49,.79),(.66,.9),(.82,.78),(1,.89),(1,1),(0,1)], (.012,.027,.085,1)),
        ]:
            cr.set_source_rgba(*color)
            first = points[0]
            cr.move_to(width*first[0], height*first[1])
            for x, y in points[1:]:
                cr.line_to(width*x, height*y)
            cr.close_path()
            cr.fill()
        cr.set_source_rgba(.13, .48, 1, .48)
        cr.set_line_width(1.1)
        cr.move_to(0, height*.82)
        cr.line_to(width*.12, height*.68)
        cr.line_to(width*.23, height*.78)
        cr.line_to(width*.34, height*.7)
        cr.line_to(width*.47, height*.83)
        cr.stroke()
        return False

    def build_versions(self):
        page = self.page('versions')
        page.pack_start(label('Play NEXUS', 'hero-title'), False, False, 0)
        page.pack_start(label('Select a published release or open a version already installed on this device.', 'hero-copy'), False, False, 0)
        versions = card('AVAILABLE VERSIONS')
        self.versions_selector = Gtk.ComboBoxText()
        self.versions_selector.set_hexpand(True)
        self.versions_selector.connect('changed', self.on_version_changed)
        self.selectors.append(self.versions_selector)
        versions.pack_start(self.versions_selector, False, False, 0)
        self.versions_notes = label('', 'release-notes')
        versions.pack_start(self.versions_notes, False, False, 0)
        versions.pack_start(label('Installed releases stay in separate folders so you can switch back at any time.', 'muted'), False, False, 0)
        page.pack_start(versions, False, False, 0)
        self.versions_installed_card = card('INSTALLED VERSIONS')
        self.versions_installed_summary = label('', 'card-copy')
        self.versions_installed_card.pack_start(self.versions_installed_summary, False, False, 0)
        page.pack_start(self.versions_installed_card, False, False, 0)

    def build_settings(self):
        page = self.page('settings')
        page.pack_start(label('Settings', 'hero-title'), False, False, 0)
        page.pack_start(label('Manage the release catalog used to find and install NEXUS versions.', 'hero-copy'), False, False, 0)
        source = card('UPDATE SOURCE')
        source.pack_start(label('Release catalog URL (HTTPS)', 'card-copy'), False, False, 0)
        self.catalog_entry = Gtk.Entry()
        self.catalog_entry.set_placeholder_text('https://your-site.example/nexus/updates/releases.json')
        self.catalog_entry.set_text(self.config.get('catalog_url', ''))
        source.pack_start(self.catalog_entry, False, False, 0)
        row = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=10)
        save = Gtk.Button(label='Save and Check')
        save.get_style_context().add_class('primary')
        save.connect('clicked', self.save_settings)
        row.pack_start(save, False, False, 0)
        source.pack_start(row, False, False, 0)
        source.pack_start(label('NEXUS accepts catalogs and client archives over HTTPS. Versions are only installed or launched after you choose them.', 'muted'), False, False, 0)
        page.pack_start(source, False, False, 0)
        about = card('RELEASE CATALOG')
        about.pack_start(label('The releases.json catalog lists versions, release notes, archive URLs, and SHA-256 checksums. The launcher verifies each package before installation.', 'card-copy'), False, False, 0)
        page.pack_start(about, False, False, 0)
        self.settings_status = label('', 'muted')
        page.pack_start(self.settings_status, False, False, 0)

    def build_logs(self):
        page = self.page('logs')
        page.pack_start(label('Logs', 'hero-title'), False, False, 0)
        page.pack_start(label('Launcher diagnostics are stored in your user account.', 'hero-copy'), False, False, 0)
        logs = card('LAUNCHER LOG')
        self.log_path_label = label(str(self.log_path()), 'card-copy')
        logs.pack_start(self.log_path_label, False, False, 0)
        logs.pack_start(label('The log file is created when the launcher is started from the applications menu.', 'muted'), False, False, 0)
        open_log = Gtk.Button(label='Open Log Folder')
        open_log.get_style_context().add_class('secondary')
        open_log.connect('clicked', lambda *_: self.open_logs())
        logs.pack_start(open_log, False, False, 0)
        page.pack_start(logs, False, False, 0)

    def build_about(self):
        page = self.page('about')
        page.pack_start(label('About NEXUS Launcher', 'hero-title'), False, False, 0)
        about = card('VERSION CONTROL CENTER')
        icon = Gtk.Image.new_from_file(str(APP_ROOT / 'static' / 'nexus-launcher.svg'))
        icon.set_pixel_size(80)
        about.pack_start(icon, False, False, 0)
        about.pack_start(label('NEXUS Launcher', 'version-large'), False, False, 0)
        metadata = read_json(APP_ROOT / 'launcher-version.json', {})
        version = metadata.get('version', '—') if isinstance(metadata, dict) else '—'
        about.pack_start(label(f'Version {version} · Linux desktop', 'card-copy'), False, False, 0)
        about.pack_start(label('Choose, install, and launch NEXUS client releases. The launcher keeps versions separate and verifies downloads with SHA-256.', 'release-notes'), False, False, 0)
        page.pack_start(about, False, False, 0)

    def navigate(self, key):
        self.stack.set_visible_child_name(key)
        for page, button in self.nav_buttons.items():
            context = button.get_style_context()
            if page == key:
                context.add_class('active')
            else:
                context.remove_class('active')

    def selected_choice(self):
        active_id = self.home_selector.get_active_id() if hasattr(self, 'home_selector') else None
        return next((choice for choice in self.choices if choice['id'] == active_id), None)

    def populate_version_selectors(self, preferred=None):
        choices = []
        if self.local_project:
            choices.append({'id': 'local', 'version': self.local_project['version'], 'label': f"{self.local_project['version']} · LOCAL PROJECT", 'source': 'local', 'path': self.local_project['path'], 'notes': 'Current version from the project directory.'})
        remote_versions = {item['version']: item for item in self.catalog}
        for version, item in sorted(remote_versions.items(), key=lambda pair: version_key(pair[0]), reverse=True):
            installed_path = self.installed.get(version)
            suffix = ' · INSTALLED' if installed_path else (' · LATEST' if version == self.latest else '')
            choices.append({'id': f'remote:{version}', 'version': version, 'label': f"{version} · {item.get('channel', 'stable').upper()}{suffix}", 'source': 'remote', 'path': installed_path, 'notes': item.get('release_notes') or 'No release notes were published for this version.', 'record': item})
        for version, install_path in sorted(self.installed.items(), key=lambda pair: version_key(pair[0]), reverse=True):
            if version not in remote_versions:
                choices.append({'id': f'installed:{version}', 'version': version, 'label': f'{version} · INSTALLED', 'source': 'installed', 'path': install_path, 'notes': 'Installed locally; this version is no longer listed in the catalog.'})
        self.choices = choices
        preferred = preferred or (self.home_selector.get_active_id() if hasattr(self, 'home_selector') else None)
        for selector in self.selectors:
            selector.remove_all()
            for choice in choices:
                selector.append(choice['id'], choice['label'])
            ids = {choice['id'] for choice in choices}
            target = preferred if preferred in ids else (choices[0]['id'] if choices else None)
            if target:
                selector.set_active_id(target)
        self.refresh_release_panel()
        self.update_selection()

    def update_selection(self, *_args):
        choice = self.selected_choice()
        if not choice:
            self.selected_summary.set_text('No versions available. Check the catalog or configure it in Settings.')
            self.install_button.set_label('NO VERSION AVAILABLE')
            self.install_button.set_sensitive(False)
            self.versions_notes.set_text('No version is selected.')
            self.player_version_label.set_text('—')
            return
        installed = bool(choice.get('path'))
        is_latest = choice['version'] == self.latest and self.latest is not None
        if choice['source'] == 'local':
            summary = 'Local project version. No download is required.'
        elif installed:
            summary = 'Installed locally · kept separate from other versions.'
        else:
            summary = 'Available to download after you confirm the install.'
        if is_latest:
            summary += ' This is the latest release in the catalog.'
        self.selected_summary.set_text(summary)
        self.versions_notes.set_text(choice.get('notes', 'No release notes.'))
        self.install_button.set_sensitive(not self.busy)
        if installed:
            action = '▶   LAUNCH NEXUS'
        elif self.local_project and version_key(choice['version']) > version_key(self.local_project['version']):
            action = f"↓   INSTALL {choice['version']}"
        else:
            action = '↓   INSTALL NEXUS'
        self.install_button.set_label(action)
        self.player_version_label.set_text(choice['version'])

    def refresh_release_panel(self):
        if not hasattr(self, 'release_list'):
            return
        for child in self.release_list.get_children():
            self.release_list.remove(child)
        latest_record = next((item for item in self.catalog if item.get('version') == self.latest), None)
        if latest_record:
            self.release_title.set_text(f"NEXUS {latest_record['version']} · {str(latest_record.get('channel', 'stable')).upper()}")
            self.release_notes.set_text(latest_record.get('release_notes') or 'No release notes were published for this version.')
            other_versions = sorted((item for item in self.catalog if item is not latest_record), key=lambda item: version_key(item['version']), reverse=True)
            for item in other_versions[:2]:
                row = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=8)
                row.pack_start(label(item['version'], 'release-version'), False, False, 0)
                summary = item.get('release_notes') or 'No release notes.'
                summary = summary.replace('\n', ' ')
                if len(summary) > 115:
                    summary = summary[:112].rstrip() + '…'
                row.pack_start(label(summary, 'muted'), True, True, 0)
                self.release_list.pack_start(row, False, False, 0)
        elif self.catalog:
            self.release_title.set_text('No latest release selected')
            self.release_notes.set_text('The catalog is available but does not designate a latest version.')
        else:
            self.release_title.set_text('No release catalog connected')
            self.release_notes.set_text('Connect a release catalog in Settings to see published versions and notes here.')
        self.release_list.show_all()

    def on_version_changed(self, selector):
        active_id = selector.get_active_id()
        if not active_id:
            return
        for other in self.selectors:
            if other is not selector and other.get_active_id() != active_id:
                other.set_active_id(active_id)
        self.update_selection()

    def set_status(self, message, style='muted'):
        for widget in (getattr(self, 'status', None), getattr(self, 'settings_status', None)):
            if widget is None:
                continue
            widget.set_text(message)
            context = widget.get_style_context()
            for name in ('muted', 'good', 'warning'):
                context.remove_class(name)
            context.add_class(style)

    def set_busy(self, busy, message=''):
        self.busy = busy
        self.check_button.set_sensitive(not busy)
        self.catalog_entry.set_sensitive(not busy)
        self.progress.set_fraction(0 if busy else self.progress.get_fraction())
        self.progress.set_text(message or ('Working…' if busy else 'Ready'))
        self.update_selection()

    def check_catalog(self, silent=False):
        url = self.config.get('catalog_url', '').strip()
        if not url:
            if not silent:
                self.set_status('Set the HTTPS release catalog URL in Settings first.', 'warning')
            return
        parsed = urllib.parse.urlparse(url)
        if parsed.scheme != 'https' or not parsed.netloc:
            self.set_status('The catalog URL must start with https://', 'warning')
            return
        if self.busy:
            return
        self.set_busy(True, 'Checking catalog…')
        self.set_status('Looking for published releases…')

        def worker():
            try:
                request = urllib.request.Request(url, headers={'User-Agent': 'NEXUS-Launcher/1.0'})
                with urllib.request.urlopen(request, timeout=20) as response:
                    if urllib.parse.urlparse(response.geturl()).scheme != 'https':
                        raise ValueError('The catalog redirected to an insecure URL.')
                    raw = response.read(MAX_CATALOG_BYTES + 1)
                if len(raw) > MAX_CATALOG_BYTES:
                    raise ValueError('The catalog exceeds the 1 MB limit.')
                catalog = json.loads(raw.decode('utf-8'))
                latest, versions = self.validate_catalog(catalog)
                GLib.idle_add(self.catalog_loaded, latest, versions, None)
            except Exception as exc:
                GLib.idle_add(self.catalog_loaded, None, None, str(exc))
        threading.Thread(target=worker, daemon=True).start()

    @staticmethod
    def validate_catalog(data):
        if not isinstance(data, dict) or data.get('schema') != 1:
            raise ValueError('Unknown catalog format; schema 1 is required.')
        latest = data.get('latest')
        if latest is not None and (not isinstance(latest, str) or not VERSION_RE.fullmatch(latest)):
            raise ValueError('The catalog latest version is invalid.')
        records = data.get('versions')
        if not isinstance(records, list) or len(records) > 100:
            raise ValueError('The catalog must contain no more than 100 releases.')
        versions, seen = [], set()
        for record in records:
            if not isinstance(record, dict):
                raise ValueError('The catalog contains an invalid release.')
            version = record.get('version')
            url = record.get('package_url')
            digest = record.get('sha256')
            if not isinstance(version, str) or not VERSION_RE.fullmatch(version) or version in seen:
                raise ValueError('A release version is invalid or duplicated.')
            if not isinstance(url, str) or urllib.parse.urlparse(url).scheme != 'https':
                raise ValueError(f'Package {version} must use an HTTPS URL.')
            if not urllib.parse.urlparse(url).netloc:
                raise ValueError(f'The package URL for {version} is invalid.')
            if not isinstance(digest, str) or not re.fullmatch(r'[a-fA-F0-9]{64}', digest):
                raise ValueError(f'The SHA-256 hash for {version} is invalid.')
            size = record.get('size')
            if not isinstance(size, int) or isinstance(size, bool) or not 1 <= size <= MAX_PACKAGE_BYTES:
                raise ValueError(f'The archive size for {version} is invalid.')
            if not isinstance(record.get('release_notes', ''), str):
                raise ValueError(f'Release notes for {version} must be text.')
            if len(record.get('release_notes', '')) > 12000:
                raise ValueError(f'Release notes for {version} exceed 12,000 characters.')
            channel = record.get('channel', 'stable')
            if not isinstance(channel, str) or not re.fullmatch(r'[A-Za-z0-9_-]{1,20}', channel):
                raise ValueError(f'The release channel for {version} is invalid.')
            seen.add(version)
            versions.append(record)
        if latest and latest not in seen:
            raise ValueError('The latest version is missing from the catalog release list.')
        return latest, versions

    def catalog_loaded(self, latest, versions, error):
        self.set_busy(False)
        if error:
            self.set_status(f'Catalog unavailable: {error}', 'warning')
            self.header_status.set_text('CATALOG OFFLINE')
            return False
        selected = self.home_selector.get_active_id()
        if latest and latest in self.installed:
            selected = f'remote:{latest}'
        elif latest and self.local_project and version_key(latest) > version_key(self.local_project['version']):
            selected = f'remote:{latest}'
        self.latest = latest
        self.catalog = versions
        self.latest_label.set_text(latest or '—')
        self.latest_description.set_text(f'{len(versions)} releases published · install only when you choose.' if versions else 'Catalog is online but no releases are published.')
        self.header_status.set_text('CATALOG ONLINE')
        self.populate_version_selectors(preferred=selected)
        self.update_installed_summary()
        self.set_status(f'Catalog updated · {len(versions)} releases available.', 'good')
        self.progress.set_fraction(1)
        self.progress.set_text('Catalog synchronized')
        return False

    def save_settings(self, *_args):
        url = self.catalog_entry.get_text().strip()
        if url and (urllib.parse.urlparse(url).scheme != 'https' or not urllib.parse.urlparse(url).netloc):
            self.set_status('Enter a valid HTTPS URL or leave the field empty.', 'warning')
            return
        self.config['catalog_url'] = url
        try:
            APP_DATA.mkdir(parents=True, exist_ok=True)
            temp = CONFIG_PATH.with_suffix('.tmp')
            temp.write_text(json.dumps(self.config, ensure_ascii=False, indent=2), encoding='utf-8')
            os.replace(temp, CONFIG_PATH)
        except OSError as exc:
            self.set_status(f'Could not save settings: {exc}', 'warning')
            return
        self.set_status('Settings saved.', 'good')
        self.check_catalog()

    def update_installed_summary(self):
        installed = []
        if self.local_project:
            installed.append(f"{self.local_project['version']} · local project")
        installed.extend(f'{version} · installed' for version in sorted(self.installed, key=version_key, reverse=True))
        if hasattr(self, 'versions_installed_summary'):
            self.versions_installed_summary.set_text('\n'.join(installed) if installed else 'No versions are installed yet.')
        if hasattr(self, 'player_installed_label'):
            self.player_installed_label.set_text(str(len(self.installed)))

    def install_or_launch(self, *_args):
        choice = self.selected_choice()
        if not choice or self.busy:
            return
        path = choice.get('path')
        if path:
            self.launch_version(Path(path))
            return
        if choice['source'] != 'remote':
            self.set_status('This version does not have a downloadable package.', 'warning')
            return
        self.install_version(choice)

    def launch_version(self, path):
        script = path / 'launch-desktop.sh'
        if not script.is_file():
            self.set_status('The selected version does not contain launch-desktop.sh.', 'warning')
            return
        try:
            if os.access(script, os.X_OK):
                command = [str(script)]
            else:
                command = ['/usr/bin/bash', str(script)]
            environment = os.environ.copy()
            environment['NEXUS_INSTANCE_ID'] = re.sub(r'[^A-Za-z0-9_-]', '_', app_version(path))
            subprocess.Popen(command, cwd=str(path), env=environment, start_new_session=True, close_fds=True)
            self.set_status(f'NEXUS {app_version(path)} launched.', 'good')
        except OSError as exc:
            self.set_status(f'Could not launch NEXUS: {exc}', 'warning')

    def install_version(self, choice):
        record = choice['record']
        self.set_busy(True, 'Preparing download…')
        self.set_status(f"Downloading NEXUS {choice['version']}…")

        def worker():
            try:
                APP_DATA.mkdir(parents=True, exist_ok=True)
                VERSIONS_DIR.mkdir(parents=True, exist_ok=True)
                fd, archive_name = tempfile.mkstemp(prefix='nexus-', suffix='.tar.gz', dir=APP_DATA)
                os.close(fd)
                archive = Path(archive_name)
                try:
                    digest, size = self.download_package(
                        record['package_url'], archive, record['size'],
                        lambda done, total: GLib.idle_add(self.download_progress, done, total))
                    if digest.lower() != record['sha256'].lower():
                        raise ValueError('SHA-256 mismatch; the package was rejected.')
                    version = choice['version']
                    destination = VERSIONS_DIR / version
                    if destination.exists():
                        raise ValueError('This version already exists on disk; published versions are immutable.')
                    with tempfile.TemporaryDirectory(prefix='nexus-install-', dir=VERSIONS_DIR) as temp_name:
                        root = self.extract_package(archive, Path(temp_name), version)
                        if not (root / 'desktop_app.py').is_file() or not (root / 'server.py').is_file() or not (root / 'launch-desktop.sh').is_file():
                            raise ValueError('The archive is missing files required by the NEXUS application.')
                        version_file = root / 'nexus-version.json'
                        if version_file.is_file() and app_version(root) != version:
                            raise ValueError('The version declared in the archive does not match the catalog.')
                        if not version_file.is_file():
                            (root / 'nexus-version.json').write_text(json.dumps({'version': version}), encoding='utf-8')
                        os.replace(root, destination)
                    GLib.idle_add(self.install_finished, version, size, None)
                finally:
                    archive.unlink(missing_ok=True)
            except Exception as exc:
                GLib.idle_add(self.install_finished, choice['version'], 0, str(exc))
        threading.Thread(target=worker, daemon=True).start()

    def download_progress(self, downloaded, total):
        fraction = min(1.0, downloaded / total) if total else 0
        self.progress.set_fraction(fraction)
        self.progress.set_text(f'Downloaded {fraction * 100:.0f}% · {downloaded / (1024 * 1024):.1f} MB')
        return False

    @staticmethod
    def download_package(url, destination, declared_size=None, progress_callback=None):
        parsed = urllib.parse.urlparse(url)
        if parsed.scheme != 'https' or not parsed.netloc:
            raise ValueError('Packages must be downloaded over HTTPS.')
        request = urllib.request.Request(url, headers={'User-Agent': 'NEXUS-Launcher/1.0'})
        digest = hashlib.sha256()
        size = 0
        last_reported = 0
        with urllib.request.urlopen(request, timeout=30) as response, destination.open('wb') as output:
            if urllib.parse.urlparse(response.geturl()).scheme != 'https':
                raise ValueError('The download redirected to an insecure URL.')
            content_length = response.headers.get('Content-Length')
            if content_length and int(content_length) > MAX_PACKAGE_BYTES:
                raise ValueError('The package exceeds the 600 MB limit.')
            while True:
                chunk = response.read(64 * 1024)
                if not chunk:
                    break
                size += len(chunk)
                if size > MAX_PACKAGE_BYTES:
                    raise ValueError('The package exceeds the 600 MB limit.')
                output.write(chunk)
                digest.update(chunk)
                if progress_callback and declared_size and (size - last_reported >= 512 * 1024 or size == declared_size):
                    progress_callback(size, declared_size)
                    last_reported = size
        if declared_size is not None and size != declared_size:
            raise ValueError('The downloaded size does not match the catalog.')
        return digest.hexdigest(), size

    @staticmethod
    def extract_package(archive, staging, version):
        with tarfile.open(archive, 'r:gz') as bundle:
            members = bundle.getmembers()
            if len(members) > MAX_ARCHIVE_FILES:
                raise ValueError('The archive contains too many files.')
            expanded_size = sum(member.size for member in members if member.isfile())
            if expanded_size > MAX_EXTRACTED_BYTES:
                raise ValueError('The extracted archive exceeds the 1.5 GB limit.')
            roots = set()
            validated = []
            for member in members:
                path = PurePosixPath(member.name)
                if path.is_absolute() or '..' in path.parts or not path.parts:
                    raise ValueError('The archive contains an unsafe path.')
                if not (member.isdir() or member.isfile()):
                    raise ValueError('The archive contains an unsupported file type.')
                roots.add(path.parts[0])
                validated.append((member, path))
            if len(roots) != 1:
                raise ValueError('The archive must contain one root directory.')
            root_name = next(iter(roots))
            if root_name not in (f'NEXUS-{version}', f'nexus-{version}'):
                raise ValueError('The archive root directory does not match the selected version.')
            for member, path in validated:
                target = staging.joinpath(*path.parts)
                if member.isdir():
                    target.mkdir(parents=True, exist_ok=True)
                    continue
                target.parent.mkdir(parents=True, exist_ok=True)
                source = bundle.extractfile(member)
                if source is None:
                    raise ValueError('An archive file could not be read.')
                with source, target.open('wb') as output:
                    shutil.copyfileobj(source, output)
                target.chmod(member.mode & 0o755)
            return staging / root_name

    def install_finished(self, version, size, error):
        self.set_busy(False)
        if error:
            self.progress.set_fraction(0)
            self.progress.set_text('Installation failed')
            self.set_status(f'Installation of version {version} was canceled: {error}', 'warning')
            return False
        self.installed = self.scan_installed()
        self.populate_version_selectors(preferred=f'remote:{version}')
        self.update_installed_summary()
        self.progress.set_fraction(1)
        self.progress.set_text('Installation complete')
        self.set_status(f'NEXUS {version} installed · {size / (1024 * 1024):.1f} MB.', 'good')
        return False


class NexusLauncher(Gtk.Application):
    def __init__(self):
        super().__init__(application_id=APP_ID)

    def do_activate(self):
        window = self.props.active_window
        if window is None:
            window = NexusLauncherWindow(self)
        window.show_all()
        window.present()


if __name__ == '__main__':
    NexusLauncher().run(None)
