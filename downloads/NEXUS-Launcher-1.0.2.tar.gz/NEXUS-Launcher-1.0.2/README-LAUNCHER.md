# NEXUS Launcher for Linux

The launcher is a small desktop application for browsing, installing, and starting published NEXUS client versions. The launcher archive contains the launcher only; the NEXUS client is downloaded separately after you choose a version.

## Requirements

- A Linux desktop with GTK 3
- Python 3 with PyGObject (`python3-gi`)

The client needs Python 3 and `psutil`. The launcher checks package size and SHA-256 before installing a client version. It keeps installed versions in separate directories under `~/.local/share/nexus-launcher/versions`.

## Install

Extract the archive, open the extracted `NEXUS-Launcher-*` folder in a terminal, and run:

```sh
./install-launcher.sh
```

Then open **NEXUS Launcher** from the applications menu. You can also start it from the extracted folder with `./launch-nexus-launcher.sh`.

The installer copies the launcher into your user account, so you can remove the extracted folder after installation.

The launcher downloads the public version catalog and client archives over HTTPS. It does not need administrator access and does not install system packages.
