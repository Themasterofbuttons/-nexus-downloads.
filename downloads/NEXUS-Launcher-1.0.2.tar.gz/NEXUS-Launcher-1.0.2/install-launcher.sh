#!/usr/bin/env bash
set -euo pipefail
project_dir="$(cd -- "$(dirname -- "$0")" && pwd -P)"
applications_dir="$HOME/.local/share/applications"
icons_dir="$HOME/.local/share/icons/hicolor/scalable/apps"
app_dir="$HOME/.local/share/nexus-launcher/app"
mkdir -p "$applications_dir" "$icons_dir" "$app_dir/static"
install -m 755 "$project_dir/nexus_launcher.py" "$project_dir/launch-nexus-launcher.sh" "$app_dir/"
install -m 644 "$project_dir/launcher_config.json" "$project_dir/launcher-version.json" "$app_dir/"
install -m 644 "$project_dir/static/nexus-launcher.svg" "$app_dir/static/nexus-launcher.svg"
python3 - "$app_dir/launch-nexus-launcher.sh" "$project_dir/nexus-launcher.desktop.in" "$applications_dir/ro.nexus.NexusLauncher.desktop" <<'PY'
from pathlib import Path
import sys
launcher, template, output = map(Path, sys.argv[1:])
exec_path = str(launcher).replace('\\', '\\\\').replace('"', '\\"').replace('%', '%%')
text = template.read_text(encoding='utf-8').replace('@LAUNCHER_PATH@', exec_path)
Path(output).write_text(text, encoding='utf-8')
PY
install -m 644 "$project_dir/static/nexus-launcher.svg" "$icons_dir/ro.nexus.NexusLauncher.svg"
printf 'NEXUS Launcher installed for your user account and added to the applications menu.\n'
