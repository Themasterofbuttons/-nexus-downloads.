#!/usr/bin/env bash
set -euo pipefail
project_dir="$(cd -- "$(dirname -- "$0")" && pwd -P)"
if [[ -t 1 ]]; then
    exec /usr/bin/python3 "$project_dir/nexus_launcher.py" "$@"
fi
state_dir="${XDG_STATE_HOME:-$HOME/.local/state}/nexus-launcher"
mkdir -p "$state_dir"
exec /usr/bin/python3 "$project_dir/nexus_launcher.py" "$@" >> "$state_dir/launcher.log" 2>&1
