# NEXUS

Dashboard sci-fi pentru monitorizarea locală a laptopului, cu panou desktop GTK și interfață web responsive. Backendul citește senzorii disponibili prin `psutil`; pagina web se actualizează la fiecare 2 secunde (intervalul poate fi schimbat din Setări). Sarcinile și notițele sunt salvate local. Vremea rămâne marcată ca indisponibilă până când este configurată o sursă reală.

## Aplicația desktop Linux

Caută **NEXUS** în Applications sau deschide scurtătura **NEXUS** de pe Desktop. Pentru pornire din terminal:

```bash
~/themasterofbuttons/launch-desktop.sh
```

Aplicația desktop folosește GTK 3 și Python GI. Aceste dependențe sunt disponibile pe instalarea curentă.

## NEXUS Launcher

Launcherul oferă selector de versiuni, instalări separate, verificare SHA-256 a arhivelor și pornirea versiunii alese. Pornește-l din proiect:

```bash
./launch-nexus-launcher.sh
```

Pentru a-l adăuga în meniul de aplicații al utilizatorului curent:

```bash
./install-launcher.sh
```

Launcherul are nevoie de Python 3, GTK 3 și PyGObject; clientul NEXUS folosește și `psutil`. Nu instalează pachete de sistem și nu cere `sudo`.

Launcherul din directorul proiectului nu are catalogul public configurat și va detecta proiectul local. Pachetul de launcher generat pentru site va include automat URL-ul catalogului HTTPS. Formatul catalogului și publicarea unei versiuni sunt descrise în [updates/README.md](updates/README.md).

## Site de descărcare și distribuție

Pagina statică este în [site/](site/), iar generatorul pregătește site-ul și pachetul launcherului:

```sh
python3 build_site.py --base-url https://domeniul-tau.example/
```

Comanda produce `site-dist/`. Pagina descarcă numai launcherul; launcherul oferă selectorul pentru versiunile clientului. Pașii de publicare sunt în [site/README.md](site/README.md). Este necesar domeniul HTTPS real înainte de a genera pachetul final.

Erorile launcherului pornit din meniul GNOME sunt în `~/.local/state/nexus-launcher/launcher.log`.

## Interfața web pe laptop

```bash
cd ~/themasterofbuttons
python3 -m pip install -r requirements.txt
./start.sh
```

Deschide `http://localhost:8765`.

## Acces de pe telefon în aceeași rețea Wi-Fi

Pornește serverul pe laptop cu:

```bash
./start.sh --host 0.0.0.0
```

Află IP-ul local al laptopului (`ip addr` pe Linux) și deschide pe telefon `http://IP-UL-LAPTOPULUI:8765`. Telefonul și laptopul trebuie să fie în aceeași rețea, iar firewallul să permită portul 8765. Serverul trebuie să rămână pornit.

## Date monitorizate

CPU și frecvența raportată, nuclee, RAM, swap, volume de stocare, uptime, procese, conexiuni, Wi-Fi, Bluetooth, baterie, temperaturi și RPM, în măsura în care hardware-ul și sistemul le expun. Consumul în wați poate fi citit de la contoare RAPL sau de la bateria sistemului. Valorile indisponibile sunt indicate explicit. Nicio informație meteo nu este simulată.

Pe Linux, `lm-sensors` poate expune senzori suplimentari. Wi-Fi și Bluetooth pot necesita `iwgetid`, `nmcli` sau `bluetoothctl`.

Dacă aplicația nu pornește, închide fereastra și verifică jurnalul din `~/.local/state/nexus/desktop.log`. Erorile de inițializare sunt afișate și în fereastra NEXUS.

Din pagina **Setări** a aplicației desktop poți selecta **Română** sau **English**. Preferința se păstrează local și se aplică interfeței după schimbarea limbii; sarcinile și notițele rămân salvate. Dashboardul nu mai include banda de acces rapid.
