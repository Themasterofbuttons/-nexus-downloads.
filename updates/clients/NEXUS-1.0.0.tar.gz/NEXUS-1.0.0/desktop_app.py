#!/usr/bin/env python3
"""NEXUS native Linux dashboard. Hardware metrics are read locally through psutil."""
import json
import os
import re
import threading
import time
import traceback
from pathlib import Path
import gi

gi.require_version('Gtk', '3.0')
gi.require_version('GdkPixbuf', '2.0')
from gi.repository import Gtk, GLib, Gdk, GdkPixbuf
from server import snapshot

DATA_DIR = Path.home() / '.local' / 'share' / 'nexus'
TASKS_FILE = DATA_DIR / 'tasks.json'
NOTES_FILE = DATA_DIR / 'notes.txt'
PREFS_FILE = DATA_DIR / 'settings.json'
TEXT = {
    'ro': {
        'subtitle':'SISTEMUL TĂU. CONTROLUL TĂU.','local':'● MONITORIZARE LOCALĂ','ok':'● SISTEM FUNCȚIONAL','sensor_error':'● SENZORI INDISPONIBILI',
        'nav_dashboard':'Dashboard','nav_system':'Sistem','nav_weather':'Vreme','nav_tasks':'Sarcini','nav_notes':'Notițe','nav_files':'Fișiere','nav_settings':'Setări',
        'sidebar_note':'Monitorizare locală\nDatele rămân pe laptop','welcome_eyebrow':'CENTRUL TĂU PERSONAL DE COMANDĂ','welcome':'Bun venit în NEXUS','welcome_desc':'O privire clară asupra sistemului tău. Date hardware citite local, în timp real.',
        'processor':'PROCESOR','memory':'MEMORIE RAM','storage':'STOCARE','energy':'ENERGIE & SISTEM','cpu_chart':'UTILIZARE CPU','ram_chart':'UTILIZARE RAM',
        'cpu':'CPU','ram':'RAM','disk':'DISK','read_wait':'Se citesc datele…','power_unavailable':'Consum curent: senzor indisponibil','battery_missing':'Baterie: nu este detectată','battery_time':'Autonomie indisponibilă','plugged':'Alimentare conectată','swap':'Swap: {used} / {total} · {pct}%','uptime':'Uptime {duration} · {count} procese',
        'system_title':'Sistem','system_desc':'Monitorizare CPU, memorie, senzori și conexiuni.','cpu_value':'CPU {pct:.1f}% · {count} fire','ram_value':'RAM {pct:.1f}% · {used} / {total}','uptime_value':'Uptime {duration}',
        'temperatures':'TEMPERATURI','fans':'VENTILATOARE · RPM','network':'REȚEA & CONEXIUNI','temps_missing':'Senzori de temperatură indisponibili.','fans_missing':'Senzori RPM indisponibili.','network_missing':'Nicio interfață detectată.',
        'weather':'VREME','weather_missing':'Nu există o sursă meteo configurată.','weather_honest':'NEXUS nu afișează temperaturi sau prognoze inventate.',
        'tasks':'Sarcini','tasks_desc':'Adaugă sarcini și marchează-le când sunt finalizate.','task_list':'LISTA TA','task_placeholder':'Scrie o sarcină nouă…','add':'Adaugă','task_empty':'Nicio sarcină încă. Adaugă una mai sus.','delete':'Șterge',
        'notes':'Notițe','notes_desc':'Notițele se salvează automat pe acest laptop.','personal':'SPAȚIU PERSONAL','saved':'Salvat local','saving':'Se salvează…','save_error':'Eroare la salvare: {error}',
        'files':'Stocare & fișiere','files_desc':'Utilizare reală pentru volumele detectate de sistem.','capacity_wait':'Capacitate totală: se citesc datele…','volumes':'VOLUME','capacity':'Capacitate montată: {used} utilizați din {total} · {count} volume','storage_missing':'Nu există date de stocare disponibile.','volumes_missing':'Nu s-au detectat volume de stocare.',
        'settings':'Setări','settings_desc':'Configurează limba și monitorizarea locală.','language':'Limbă','monitoring':'MONITORIZARE','refresh_rate':'Frecvență citire senzori','every2':'La fiecare 2 secunde','every5':'La fiecare 5 secunde','every10':'La fiecare 10 secunde','weather_source':'Sursă meteo neconfigurată · nicio valoare fictivă nu este afișată.',
        'refresh':'Actualizează acum','status_wait':'Aștept datele senzorilor…','updated':'Actualizat {time} · Date hardware citite local','threads':'{count} fire','frequency_missing':'{count} fire · frecvență N/A','ram_used':'{used} utilizați din {total}','disk_used':'{used} din {total}','capacity_missing':'Capacitate indisponibilă',
        'power_value':'Consum curent: {watts:.1f} W','battery_value':'Baterie: {pct:.0f}% · {state}','charging':'la încărcat','on_battery':'pe baterie','autonomy':'Autonomie: {duration}','cpu_frequency':'{count} fire · {ghz:.1f} GHz',
        'wifi_off':'Deconectat','wifi_unavailable':'Indisponibil','bt_unknown':'Necunoscut','bt_on':'Pornit','bt_off':'Oprit','no_ip':'fără IP','active':'activă','inactive':'inactivă','tcp':'Conexiuni','udp':'TCP {tcp} · UDP {udp}','connections_unavailable':'Indisponibil',
        'settings_error':'Nu s-au putut salva setările: {error}','language_ro':'Română','language_en':'English','days':'zile','hours':'h','minutes':'min'
    },
    'en': {
        'subtitle':'YOUR SYSTEM. YOUR CONTROL.','local':'● LOCAL MONITORING','ok':'● SYSTEM OPERATIONAL','sensor_error':'● SENSORS UNAVAILABLE',
        'nav_dashboard':'Dashboard','nav_system':'System','nav_weather':'Weather','nav_tasks':'Tasks','nav_notes':'Notes','nav_files':'Storage','nav_settings':'Settings',
        'sidebar_note':'Local monitoring\nYour data stays on this laptop','welcome_eyebrow':'YOUR PERSONAL COMMAND CENTER','welcome':'Welcome to NEXUS','welcome_desc':'A clear view of your system. Hardware data, read locally in real time.',
        'processor':'PROCESSOR','memory':'RAM MEMORY','storage':'STORAGE','energy':'POWER & SYSTEM','cpu_chart':'CPU USAGE','ram_chart':'RAM USAGE',
        'cpu':'CPU','ram':'RAM','disk':'DISK','read_wait':'Reading data…','power_unavailable':'Power draw: sensor unavailable','battery_missing':'Battery: not detected','battery_time':'Remaining time unavailable','plugged':'Power connected','swap':'Swap: {used} / {total} · {pct}%','uptime':'Uptime {duration} · {count} processes',
        'system_title':'System','system_desc':'Monitor CPU, memory, sensors and connections.','cpu_value':'CPU {pct:.1f}% · {count} threads','ram_value':'RAM {pct:.1f}% · {used} / {total}','uptime_value':'Uptime {duration}',
        'temperatures':'TEMPERATURES','fans':'FANS · RPM','network':'NETWORK & CONNECTIONS','temps_missing':'Temperature sensors unavailable.','fans_missing':'Fan speed sensors unavailable.','network_missing':'No network interfaces detected.',
        'weather':'WEATHER','weather_missing':'No weather source is configured.','weather_honest':'NEXUS does not show invented temperatures or forecasts.',
        'tasks':'Tasks','tasks_desc':'Add tasks and mark them complete when finished.','task_list':'YOUR LIST','task_placeholder':'Write a new task…','add':'Add','task_empty':'No tasks yet. Add one above.','delete':'Delete',
        'notes':'Notes','notes_desc':'Notes are saved automatically on this laptop.','personal':'PERSONAL SPACE','saved':'Saved locally','saving':'Saving…','save_error':'Could not save: {error}',
        'files':'Storage & files','files_desc':'Actual usage for volumes detected by the system.','capacity_wait':'Total capacity: reading data…','volumes':'VOLUMES','capacity':'Mounted capacity: {used} used of {total} · {count} volumes','storage_missing':'Storage data is unavailable.','volumes_missing':'No storage volumes detected.',
        'settings':'Settings','settings_desc':'Configure language and local monitoring.','language':'Language','monitoring':'MONITORING','refresh_rate':'Sensor refresh rate','every2':'Every 2 seconds','every5':'Every 5 seconds','every10':'Every 10 seconds','weather_source':'No weather source configured · no fictional values are shown.',
        'refresh':'Refresh now','status_wait':'Waiting for sensor data…','updated':'Updated {time} · Hardware data read locally','threads':'{count} threads','frequency_missing':'{count} threads · frequency N/A','ram_used':'{used} used of {total}','disk_used':'{used} of {total}','capacity_missing':'Capacity unavailable',
        'power_value':'Power draw: {watts:.1f} W','battery_value':'Battery: {pct:.0f}% · {state}','charging':'charging','on_battery':'on battery','autonomy':'Estimated remaining: {duration}','cpu_frequency':'{count} threads · {ghz:.1f} GHz',
        'wifi_off':'Disconnected','wifi_unavailable':'Unavailable','bt_unknown':'Unknown','bt_on':'On','bt_off':'Off','no_ip':'no IP','active':'active','inactive':'inactive','tcp':'Connections','udp':'TCP {tcp} · UDP {udp}','connections_unavailable':'Unavailable',
        'settings_error':'Could not save settings: {error}','language_ro':'Romanian','language_en':'English','days':'days','hours':'h','minutes':'min'
    }
}
CSS = b'''
window, .background { background: #030817; color: #e5f4ff; }
headerbar { background: #050d20; border-bottom: 1px solid #1676b2; color: #e8f5ff; min-height: 42px; }
headerbar .title { color: #dffaff; font-weight: 700; }
.sidebar { background: #040b1b; border-right: 1px solid #17395a; padding: 10px 8px; }
.sidebar button { color: #9bc3df; background: transparent; border: 1px solid transparent; border-radius: 8px; padding: 9px; }
.sidebar button:hover, .sidebar button:focus { color: #4be4ff; background: #0a2340; border-color: #147db1; }
.sidebar button.active { color: #65eaff; background: #092344; border-color: #168bc4; }
.card { background: #07152b; border: 1px solid #1c5b85; border-radius: 10px; padding: 14px; }
.card-title { color: #55dfff; font-size: 9px; font-weight: 700; letter-spacing: 1px; }
.big { color: #edfbff; font: 600 24px 'DejaVu Sans'; }
.detail { color: #a4c1d8; font-size: 10px; }
.dim { color: #7897b1; font-size: 9px; }
.good { color: #54e6c0; } .violet { color: #d281ff; } .amber { color: #ffd16e; }
button.action { background: #0a3260; border: 1px solid #1889c8; color: #a9edff; border-radius: 6px; padding: 6px 10px; }
entry, textview { background: #051126; color: #dff3ff; border: 1px solid #214d73; border-radius: 5px; padding: 8px; }
progress trough { background: #172c46; border-radius: 8px; min-height: 7px; }
progress progress { background: #28d8ef; border-radius: 8px; min-height: 7px; }
separator { background: #173853; }
checkbutton { color: #d0e4f2; font-size: 10px; }
headerbar { background-image: linear-gradient(to bottom, #08162c, #040b19); box-shadow: 0 2px 16px rgba(0, 8, 24, .55); }
.sidebar { background-image: linear-gradient(to bottom, #071329, #030918 78%); }
.card { background-image: linear-gradient(145deg, #0a1b34, #061226 72%); border-color: #246b98; border-radius: 12px; padding: 16px; box-shadow: 0 8px 24px rgba(0, 7, 20, .35), inset 0 1px rgba(175, 230, 255, .035); }
.card:hover { border-color: #35b7e8; box-shadow: 0 0 18px rgba(29, 158, 255, .12), 0 8px 24px rgba(0, 7, 20, .4); }
.card-title { font-size: 10px; letter-spacing: 1.15px; }
.detail { font-size: 11px; }
.dim { font-size: 10px; }
button.action { background-image: linear-gradient(to bottom, #0d4271, #08274c); border-color: #259bd1; box-shadow: 0 3px 12px rgba(0, 150, 255, .14); }
button.action:hover { background-image: linear-gradient(to bottom, #12609a, #0a3761); border-color: #4cdbff; color: #ffffff; }
entry:focus, textview:focus { border-color: #43dcff; box-shadow: 0 0 0 2px rgba(27, 184, 255, .17); }
progress progress { background-image: linear-gradient(to right, #18bfff, #35efc0); }
'''


def bytestr(n):
    if not n: return '0 B'
    units=['B','KB','MB','GB','TB']; i=0
    while n>=1024 and i<len(units)-1: n/=1024; i+=1
    return f'{n:.1f} {units[i]}'


def label(text, style=None, x=0):
    w=Gtk.Label(label=text); w.set_xalign(x)
    if style: w.get_style_context().add_class(style)
    return w


def svg_pixbuf(svg):
    loader=GdkPixbuf.PixbufLoader.new_with_type('svg')
    loader.write(svg.encode('utf-8')); loader.close()
    return loader.get_pixbuf()


def ring_svg(title,color,value,text=None):
    value=max(0,min(100,float(value)));text=text or f'{value:.0f}%';circ=226.2;offset=circ*(1-value/100)
    return f'''<svg xmlns="http://www.w3.org/2000/svg" width="116" height="116" viewBox="0 0 116 116">
    <defs><radialGradient id="g"><stop stop-color="#0b2140"/><stop offset="1" stop-color="#030b1b"/></radialGradient><filter id="f"><feGaussianBlur stdDeviation="3" result="b"/><feMerge><feMergeNode in="b"/><feMergeNode in="SourceGraphic"/></feMerge></filter></defs>
    <circle cx="58" cy="58" r="39" fill="url(#g)" stroke="#163257" stroke-width="1"/>
    <circle cx="58" cy="58" r="36" fill="none" stroke="#102746" stroke-width="7"/>
    <circle cx="58" cy="58" r="36" fill="none" stroke="{color}" stroke-width="7" stroke-linecap="round" stroke-dasharray="{circ}" stroke-dashoffset="{offset}" transform="rotate(-90 58 58)" filter="url(#f)"/>
    <text x="58" y="57" text-anchor="middle" fill="#edfaff" font-family="DejaVu Sans" font-size="18" font-weight="600">{text}</text>
    <text x="58" y="73" text-anchor="middle" fill="#65c9e8" font-family="DejaVu Sans" font-size="8" letter-spacing="1">{title}</text></svg>'''


def history_svg(points,color):
    w,h=600,145;pad=9
    grid=''.join(f'<line x1="{pad}" y1="{pad+i*(h-2*pad)/4:.1f}" x2="{w-pad}" y2="{pad+i*(h-2*pad)/4:.1f}" stroke="#173752" stroke-width="1"/>' for i in range(5))
    if len(points)>1:
        coords=[]
        for i,value in enumerate(points):
            x=pad+i*(w-2*pad)/(len(points)-1);y=h-pad-max(0,min(100,value))/100*(h-2*pad);coords.append(f'{x:.1f},{y:.1f}')
        line=' '.join(coords);area=f'<polygon points="{pad},{h-pad} {line} {w-pad},{h-pad}" fill="{color}" opacity=".12"/><polyline points="{line}" fill="none" stroke="{color}" stroke-width="2" stroke-linejoin="round" stroke-linecap="round"/>'
    else:area=''
    return f'<svg xmlns="http://www.w3.org/2000/svg" width="{w}" height="{h}" viewBox="0 0 {w} {h}">{grid}{area}</svg>'


class Ring(Gtk.Image):
    def __init__(self,title,color):
        super().__init__(); self.title=title; self.color=color; self.set_size_request(116,116); self.set_value(0,'—')
    def set_value(self,value,text=None):
        self.set_from_pixbuf(svg_pixbuf(ring_svg(self.title,self.color,value,text)))


class History(Gtk.Image):
    def __init__(self,color): super().__init__(); self.color=color; self.set_size_request(480,145); self.set_points([])
    def set_points(self,points):
        self.set_from_pixbuf(svg_pixbuf(history_svg(points,self.color)))


class NexusWindow(Gtk.ApplicationWindow):
    NAV=[('⌂','nav_dashboard','dashboard'),('▣','nav_system','system'),('☼','nav_weather','weather'),('☑','nav_tasks','tasks'),('▤','nav_notes','notes'),('▱','nav_files','files'),('⚙','nav_settings','settings')]
    def __init__(self,app,language='ro',start_page='dashboard'):
        self.app=app;self.language=language if language in TEXT else 'ro';self.start_page=start_page
        super().__init__(application=app,title='NEXUS');self.set_default_size(1320,900);self.set_position(Gtk.WindowPosition.CENTER)
        self.set_icon_name('utilities-system-monitor');self.active_nav={}
        provider=Gtk.CssProvider();provider.load_from_data(CSS);Gtk.StyleContext.add_provider_for_screen(Gdk.Screen.get_default(),provider,Gtk.STYLE_PROVIDER_PRIORITY_APPLICATION)
        header=Gtk.HeaderBar();header.set_show_close_button(True);header.props.title='N E X U S';header.props.subtitle=self.t('subtitle');self.set_titlebar(header)
        self.clock=label('--:--','big');header.pack_end(self.clock)
        refresh=Gtk.Button.new_from_icon_name('view-refresh-symbolic',Gtk.IconSize.BUTTON);refresh.set_tooltip_text('Actualizează acum');refresh.connect('clicked',lambda *_:self.fetch());header.pack_end(refresh)
        self.status=label(self.t('local'),'good');header.pack_start(self.status)
        shell=Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL,spacing=0);self.add(shell)
        sidebar=Gtk.Box(orientation=Gtk.Orientation.VERTICAL,spacing=6);sidebar.set_size_request(166,-1);sidebar.get_style_context().add_class('sidebar');shell.pack_start(sidebar,False,False,0)
        brand=label('◉  NEXUS','big');brand.set_margin_top(10);brand.set_margin_bottom(22);sidebar.pack_start(brand,False,False,4)
        for icon,title_key,key in self.NAV:
            button=Gtk.Button(label=f'{icon}   {self.t(title_key)}');button.set_relief(Gtk.ReliefStyle.NONE);button.connect('clicked',self.navigate,key);sidebar.pack_start(button,False,False,0);self.active_nav[key]=button
        sidebar.pack_end(label(self.t('sidebar_note'),'dim'),False,False,10)
        self.stack=Gtk.Stack(transition_type=Gtk.StackTransitionType.CROSSFADE,transition_duration=150);self.stack.set_hexpand(True);self.stack.set_vexpand(True);shell.pack_start(self.stack,True,True,0)
        self.cpu_points=[];self.ram_points=[];self.build_dashboard();self.build_system();self.build_weather();self.build_tasks();self.build_notes();self.build_files();self.build_settings()
        self.connect('delete-event',self.on_close)
        self.navigate(None,start_page);self.load_local();self.fetch();GLib.timeout_add_seconds(1,self.update_clock);self.set_refresh_interval(int(self.rate.get_active_id() or '2')*1000)

    def t(self,key,**values):
        value=TEXT[self.language][key]
        return value.format(**values) if values else value

    def page(self,key):
        scroll=Gtk.ScrolledWindow();scroll.set_policy(Gtk.PolicyType.AUTOMATIC,Gtk.PolicyType.AUTOMATIC)
        content=Gtk.Box(orientation=Gtk.Orientation.VERTICAL,spacing=12);content.set_margin_top(17);content.set_margin_bottom(20);content.set_margin_start(19);content.set_margin_end(19);scroll.add(content);self.stack.add_named(scroll,key);return content
    def card(self,title):
        box=Gtk.Box(orientation=Gtk.Orientation.VERTICAL,spacing=8);box.get_style_context().add_class('card');box.pack_start(label(title,'card-title'),False,False,1);return box
    def row(self,parent,spacing=12):
        box=Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL,spacing=spacing);parent.pack_start(box,False,False,0);return box
    def add_nav_target(self,key,title,subtitle):
        head=Gtk.Box(orientation=Gtk.Orientation.VERTICAL,spacing=4);head.pack_start(label(title,'big'),False,False,0);head.pack_start(label(subtitle,'detail'),False,False,0);return head
    def build_dashboard(self):
        page=self.page('dashboard');welcome=self.card(self.t('welcome_eyebrow'));welcome.pack_start(label(self.t('welcome'),'big'),False,False,2);welcome.pack_start(label(self.t('welcome_desc'),'detail'),False,False,1);page.pack_start(welcome,False,False,0)
        metrics=self.row(page,10);self.cpu_ring=Ring(self.t('cpu'),'#37dbff');self.ram_ring=Ring(self.t('ram'),'#ca5aff');self.disk_ring=Ring(self.t('disk'),'#32e6b0')
        self.cpu_label=label(self.t('read_wait'),'detail');self.ram_label=label(self.t('read_wait'),'detail');self.disk_label=label(self.t('read_wait'),'detail')
        for title,ring,desc in [(self.t('processor'),self.cpu_ring,self.cpu_label),(self.t('memory'),self.ram_ring,self.ram_label),(self.t('storage'),self.disk_ring,self.disk_label)]:
            card=self.card(title);card.set_hexpand(True);card.set_size_request(150,175);card.pack_start(ring,True,True,0);ring.set_halign(Gtk.Align.CENTER);desc.set_halign(Gtk.Align.CENTER);card.pack_start(desc,False,False,1);metrics.pack_start(card,True,True,0)
        energy=self.card(self.t('energy'));energy.set_hexpand(True);energy.set_size_request(220,175);self.power=label(self.t('power_unavailable'),'amber');self.battery=label(self.t('battery_missing'),'good');self.battery_time=label(self.t('battery_time'),'dim');self.swap_info=label(self.t('swap',used='—',total='—',pct=0),'detail');self.host_info=label(self.t('uptime',duration='—',count='—'),'detail')
        for widget in [self.power,self.battery,self.battery_time,self.swap_info,self.host_info]:energy.pack_start(widget,False,False,3)
        metrics.pack_start(energy,True,True,0)
        chartrow=self.row(page,10);self.cpu_history=History('#28dfff');self.ram_history=History('#cf4dff')
        for title,chart in [(self.t('cpu_chart'),self.cpu_history),(self.t('ram_chart'),self.ram_history)]:
            card=self.card(title);card.set_hexpand(True);chart.set_halign(Gtk.Align.FILL);card.pack_start(chart,True,True,0);chartrow.pack_start(card,True,True,0)
        self.dashboard_status=label(self.t('status_wait'),'dim');page.pack_start(self.dashboard_status,False,False,0)

    def build_system(self):
        page=self.page('system');page.pack_start(self.add_nav_target('system',self.t('system_title'),self.t('system_desc')),False,False,2)
        summary=self.row(page,10);self.system_cpu=label('CPU: —','good');self.system_ram=label('RAM: —','violet');self.system_uptime=label('Uptime: —','detail')
        for title,w in [(self.t('processor'),self.system_cpu),(self.t('memory'),self.system_ram),('SYSTEM' if self.language=='en' else 'SISTEM',self.system_uptime)]:
            card=self.card(title);card.set_hexpand(True);card.pack_start(w,False,False,8);summary.pack_start(card,True,True,0)
        self.temps_box=Gtk.Box(orientation=Gtk.Orientation.VERTICAL,spacing=5);self.fans_box=Gtk.Box(orientation=Gtk.Orientation.VERTICAL,spacing=5)
        sensors=self.row(page,10)
        for title,box in [(self.t('temperatures'),self.temps_box),(self.t('fans'),self.fans_box)]:
            card=self.card(title);card.set_hexpand(True);card.pack_start(box,True,True,4);sensors.pack_start(card,True,True,0)
        self.network_box=Gtk.Box(orientation=Gtk.Orientation.VERTICAL,spacing=5);network=self.card(self.t('network'));network.pack_start(self.network_box,True,True,4);page.pack_start(network,False,False,0)

    def build_weather(self):
        page=self.page('weather');card=self.card(self.t('weather'));card.set_size_request(-1,220);card.pack_start(label('☼','big'),False,False,5);card.pack_start(label(self.t('weather_missing'),'detail'),False,False,0);card.pack_start(label(self.t('weather_honest'),'dim'),False,False,0);page.pack_start(card,False,False,0)

    def build_tasks(self):
        page=self.page('tasks');page.pack_start(self.add_nav_target('tasks',self.t('tasks'),self.t('tasks_desc')),False,False,2)
        card=self.card(self.t('task_list'));form=self.row(card,8);self.task_entry=Gtk.Entry();self.task_entry.set_placeholder_text(self.t('task_placeholder'));self.task_entry.connect('activate',self.add_task);form.pack_start(self.task_entry,True,True,0);add=Gtk.Button(label=self.t('add'));add.get_style_context().add_class('action');add.connect('clicked',self.add_task);form.pack_start(add,False,False,0)
        self.tasks_box=Gtk.Box(orientation=Gtk.Orientation.VERTICAL,spacing=4);tasks_scroll=Gtk.ScrolledWindow();tasks_scroll.set_policy(Gtk.PolicyType.NEVER,Gtk.PolicyType.AUTOMATIC);tasks_scroll.set_min_content_height(240);tasks_scroll.add(self.tasks_box);card.pack_start(tasks_scroll,True,True,5);page.pack_start(card,True,True,0)

    def build_notes(self):
        page=self.page('notes');page.pack_start(self.add_nav_target('notes',self.t('notes'),self.t('notes_desc')),False,False,2)
        card=self.card(self.t('personal'));self.notes_view=Gtk.TextView();self.notes_view.set_wrap_mode(Gtk.WrapMode.WORD_CHAR);self.notes_view.set_size_request(-1,440);self.notes_view.set_left_margin(10);self.notes_view.set_right_margin(10);self.notes_view.set_top_margin(10);self.notes_view.set_bottom_margin(10)
        note_scroll=Gtk.ScrolledWindow();note_scroll.set_policy(Gtk.PolicyType.AUTOMATIC,Gtk.PolicyType.AUTOMATIC);note_scroll.set_vexpand(True);note_scroll.add(self.notes_view);card.pack_start(note_scroll,True,True,0);self.notes_status=label(self.t('saved'),'dim');card.pack_start(self.notes_status,False,False,0);page.pack_start(card,True,True,0)

    def build_files(self):
        page=self.page('files');page.pack_start(self.add_nav_target('files',self.t('files'),self.t('files_desc')),False,False,2)
        self.disk_summary=label(self.t('capacity_wait'),'detail');page.pack_start(self.disk_summary,False,False,0)
        self.disk_box=Gtk.Box(orientation=Gtk.Orientation.VERTICAL,spacing=8);card=self.card(self.t('volumes'));card.pack_start(self.disk_box,True,True,3);page.pack_start(card,False,False,0)

    def build_settings(self):
        page=self.page('settings');page.pack_start(self.add_nav_target('settings',self.t('settings'),self.t('settings_desc')),False,False,2)
        language_card=self.card(self.t('language').upper());lang_line=self.row(language_card,12);lang_line.pack_start(label(self.t('language'),'detail'),True,True,0);self.language_combo=Gtk.ComboBoxText();self.language_combo.append('ro','Română');self.language_combo.append('en','English');self.language_combo.set_active_id(self.language);self.language_combo.connect('changed',self.change_language);lang_line.pack_end(self.language_combo,False,False,0);page.pack_start(language_card,False,False,0)
        card=self.card(self.t('monitoring'));line=self.row(card,12);line.pack_start(label(self.t('refresh_rate'),'detail'),True,True,0);self.rate=Gtk.ComboBoxText();self.rate.append('2',self.t('every2'));self.rate.append('5',self.t('every5'));self.rate.append('10',self.t('every10'));self.rate.connect('changed',self.change_rate);line.pack_end(self.rate,False,False,0);page.pack_start(card,False,False,0)
        weather=self.card(self.t('weather'));weather.pack_start(label(self.t('weather_source'),'detail'),False,False,0);page.pack_start(weather,False,False,0)

    def navigate(self,button,key):
        if key not in self.active_nav:return
        self.stack.set_visible_child_name(key)
        for name,item in self.active_nav.items():
            context=item.get_style_context()
            if name==key:context.add_class('active')
            else:context.remove_class('active')

    def fetch(self,*_):
        if getattr(self,'fetch_busy',False):return True
        self.fetch_busy=True
        def worker():
            try:data=snapshot();GLib.idle_add(self.render,data,None)
            except Exception as exc:GLib.idle_add(self.render,None,str(exc))
        threading.Thread(target=worker,daemon=True).start();return True

    def rows(self,box,items,empty):
        for child in box.get_children():box.remove(child)
        if not items:box.pack_start(label(empty,'dim'),False,False,0)
        for title,value in items:
            line=Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL,spacing=10);line.pack_start(label(title,'detail'),True,True,0);line.pack_end(label(value,'good'),False,False,0);box.pack_start(line,False,False,3)
        box.show_all()

    def render(self,data,error):
        self.fetch_busy=False
        if getattr(self,'closed',False):return False
        if error:self.status.set_text(self.t('sensor_error'));self.dashboard_status.set_text(error);return False
        self.status.set_text(self.t('ok'));cpu=data['cpu'];ram=data['ram'];self.cpu_ring.set_value(cpu,f'{cpu:.0f}%');self.ram_ring.set_value(ram['percent'],f"{ram['percent']:.0f}%")
        disks=data['disks'];total=sum(x['total'] for x in disks);used=sum(x['used'] for x in disks);pct=(used/total*100) if total else 0;self.disk_ring.set_value(pct,f'{pct:.0f}%' if total else 'N/A')
        self.cpu_label.set_text(self.t('cpu_frequency',count=len(data['cores']),ghz=data['host']['cpu_mhz']/1000) if data['host']['cpu_mhz'] else self.t('frequency_missing',count=len(data['cores'])))
        self.ram_label.set_text(self.t('ram_used',used=bytestr(ram['used']),total=bytestr(ram['total'])));self.disk_label.set_text(self.t('disk_used',used=bytestr(used),total=bytestr(total)) if total else self.t('capacity_missing'))
        self.power.set_text(self.t('power_value',watts=data['power_w']) if data['power_w'] is not None else self.t('power_unavailable'))
        battery=data['battery'];state=self.t('charging') if battery and battery['plugged'] else self.t('on_battery')
        self.battery.set_text(self.t('battery_value',pct=battery['percent'],state=state) if battery else self.t('battery_missing'))
        self.battery_time.set_text(self.t('autonomy',duration=self.duration(battery['seconds'])) if battery and battery['seconds']>0 else (self.t('plugged') if battery and battery['plugged'] else self.t('battery_time')))
        self.swap_info.set_text(self.t('swap',used=bytestr(data['swap']['used']),total=bytestr(data['swap']['total']),pct=data['swap']['percent']))
        self.host_info.set_text(self.t('uptime',duration=self.duration(data['host']['uptime_s']),count=data['host']['processes']))
        self.system_cpu.set_text(self.t('cpu_value',pct=cpu,count=len(data['cores'])));self.system_ram.set_text(self.t('ram_value',pct=ram['percent'],used=bytestr(ram['used']),total=bytestr(ram['total'])));self.system_uptime.set_text(self.t('uptime_value',duration=self.duration(data['host']['uptime_s'])))
        self.cpu_points=(self.cpu_points+[cpu])[-60:];self.ram_points=(self.ram_points+[ram['percent']])[-60:];self.cpu_history.set_points(self.cpu_points);self.ram_history.set_points(self.ram_points)
        self.rows(self.temps_box,[(x['name'],f"{x['c']:.1f} °C") for x in data['temps']],self.t('temps_missing'))
        self.rows(self.fans_box,[(x['name'],f"{x['rpm']} RPM") for x in data['fans']],self.t('fans_missing'))
        self.rows(self.network_box,self.network_rows(data),self.t('network_missing'))
        for child in self.disk_box.get_children():self.disk_box.remove(child)
        self.disk_summary.set_text(self.t('capacity',used=bytestr(used),total=bytestr(total),count=len(disks)) if total else self.t('storage_missing'))
        if not disks:self.disk_box.pack_start(label(self.t('volumes_missing'),'dim'),False,False,0)
        for drive in disks:
            card=self.card(f"{drive['mount']}  ·  {drive['device']}");card.set_hexpand(True)
            line=Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL,spacing=8);line.pack_start(label(f"{bytestr(drive['used'])} utilizați din {bytestr(drive['total'])}",'detail'),True,True,0);line.pack_end(label(f"{drive['percent']:.1f}%",'good'),False,False,0);card.pack_start(line,False,False,3)
            bar=Gtk.ProgressBar();bar.set_fraction(drive['percent']/100);card.pack_start(bar,False,False,3);self.disk_box.pack_start(card,False,False,0)
        self.disk_box.show_all();self.dashboard_status.set_text(self.t('updated',time=time.strftime('%H:%M:%S')))
        return False

    def network_rows(self,data):
        wireless=data['wireless']
        wifi=wireless['wifi'] or (self.t('wifi_off') if wireless.get('wifi_available',True) else self.t('wifi_unavailable'))
        bt=(self.t('wifi_unavailable') if wireless.get('bluetooth_available') is False else self.t('bt_unknown')) if wireless['bluetooth'] is None else (self.t('bt_on') if wireless['bluetooth'] else self.t('bt_off'))
        tcp=data['connections']['tcp'];udp=data['connections']['udp']
        counts=self.t('udp',tcp=tcp if tcp is not None else '—',udp=udp if udp is not None else '—') if tcp is not None or udp is not None else self.t('connections_unavailable')
        return [('Wi-Fi',wifi),('Bluetooth',bt),(self.t('tcp'),counts)]+[(x['name'],(x['ip'] or self.t('no_ip'))+(' · '+self.t('active') if x['up'] else ' · '+self.t('inactive'))) for x in data['interfaces']]

    def duration(self,seconds):
        seconds=max(0,int(seconds));days=seconds//86400;hours=seconds%86400//3600;minutes=seconds%3600//60
        return f"{days} {self.t('days')} {hours} {self.t('hours')}" if days else (f"{hours} {self.t('hours')} {minutes} {self.t('minutes')}" if hours else f"{minutes} {self.t('minutes')}")
    def update_clock(self):self.clock.set_text(time.strftime('%H:%M'));return True

    def load_local(self):
        DATA_DIR.mkdir(parents=True,exist_ok=True)
        try:self.tasks=json.loads(TASKS_FILE.read_text())
        except (OSError,ValueError):self.tasks=[]
        if not isinstance(self.tasks,list):self.tasks=[]
        self.tasks=[task for task in self.tasks if isinstance(task,dict) and isinstance(task.get('text'),str)]
        self.render_tasks()
        try:note=NOTES_FILE.read_text()
        except OSError:note=''
        self.loading_note=True;self.notes_view.get_buffer().set_text(note);self.loading_note=False;self.notes_view.get_buffer().connect('changed',self.save_note)
        try:prefs=json.loads(PREFS_FILE.read_text())
        except (OSError,ValueError):prefs={}
        if not isinstance(prefs,dict):prefs={}
        value=str(prefs.get('refresh',2))
        self.rate.set_active_id(value if value in ('2','5','10') else '2')

    def render_tasks(self):
        for child in self.tasks_box.get_children():self.tasks_box.remove(child)
        if not self.tasks:self.tasks_box.pack_start(label(self.t('task_empty'),'dim'),False,False,8)
        for index,item in enumerate(self.tasks):
            line=Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL,spacing=7);check=Gtk.CheckButton(label=item['text']);check.set_active(item.get('done',False));check.connect('toggled',self.toggle_task,index);line.pack_start(check,True,True,0)
            remove=Gtk.Button(label=self.t('delete'));remove.set_relief(Gtk.ReliefStyle.NONE);remove.connect('clicked',self.remove_task,index);line.pack_end(remove,False,False,0);self.tasks_box.pack_start(line,False,False,2)
        self.tasks_box.show_all()
    def save_tasks(self):
        try:TASKS_FILE.write_text(json.dumps(self.tasks,ensure_ascii=False,indent=2))
        except OSError as exc:self.dashboard_status.set_text(f'Nu s-au putut salva sarcinile: {exc}')
    def add_task(self,widget):
        text=self.task_entry.get_text().strip()
        if not text:return
        self.tasks.insert(0,{'text':text,'done':False});self.task_entry.set_text('');self.save_tasks();self.render_tasks()
    def toggle_task(self,button,index):
        if index<len(self.tasks):self.tasks[index]['done']=button.get_active();self.save_tasks()
    def remove_task(self,button,index):
        if index<len(self.tasks):self.tasks.pop(index);self.save_tasks();self.render_tasks()
    def save_note(self,buffer):
        if getattr(self,'loading_note',False):return
        if getattr(self,'note_source',0):GLib.source_remove(self.note_source)
        self.notes_status.set_text(self.t('saving'));self.note_source=GLib.timeout_add(400,self.write_note)
    def write_note(self):
        buffer=self.notes_view.get_buffer();text=buffer.get_text(buffer.get_start_iter(),buffer.get_end_iter(),True)
        try:NOTES_FILE.write_text(text);self.notes_status.set_text(self.t('saved'))
        except OSError as exc:self.notes_status.set_text(self.t('save_error',error=exc))
        self.note_source=0;return False
    def on_close(self,*_):
        self.closed=True
        self.flush_local()
        return False
    def flush_local(self):
        if getattr(self,'note_source',0):GLib.source_remove(self.note_source);self.note_source=0
        self.write_note();self.save_tasks()
    def change_language(self,combo):
        language=combo.get_active_id()
        if language and language!=self.language:self.app.change_language(language)
    def change_rate(self,combo):
        value=combo.get_active_id()
        if value:self.set_refresh_interval(int(value)*1000)
    def set_refresh_interval(self,ms):
        if getattr(self,'refresh_source',0):GLib.source_remove(self.refresh_source)
        self.refresh_source=GLib.timeout_add_seconds(max(1,ms//1000),self.fetch)
        self.save_preference('refresh',ms//1000)
    def save_preference(self,key,value):
        try:prefs=json.loads(PREFS_FILE.read_text())
        except (OSError,ValueError):prefs={}
        if not isinstance(prefs,dict):prefs={}
        prefs[key]=value
        try:PREFS_FILE.write_text(json.dumps(prefs,ensure_ascii=False,indent=2))
        except OSError as exc:self.dashboard_status.set_text(self.t('settings_error',error=exc))

class App(Gtk.Application):
    def __init__(self):
        version_instance=os.environ.get('NEXUS_INSTANCE_ID','').strip()
        application_id='ro.nexus.SystemDashboard'
        if version_instance and re.fullmatch(r'[A-Za-z0-9_-]{1,40}',version_instance):
            application_id+=f'.v{version_instance}'
        super().__init__(application_id=application_id)
    def do_activate(self):
        try:
            win=self.props.active_window
            if not win:
                try:prefs=json.loads(PREFS_FILE.read_text())
                except (OSError,ValueError):prefs={}
                if not isinstance(prefs,dict):prefs={}
                win=NexusWindow(self,prefs.get('language','ro'))
            win.show_all();win.present()
        except Exception as exc:
            traceback.print_exc();current=self.props.active_window
            if current:current.destroy()
            win=Gtk.ApplicationWindow(application=self,title='NEXUS — eroare la pornire');win.set_default_size(620,220)
            box=Gtk.Box(orientation=Gtk.Orientation.VERTICAL,spacing=12);box.set_margin_top(24);box.set_margin_bottom(24);box.set_margin_start(24);box.set_margin_end(24)
            box.pack_start(label('NEXUS nu a putut porni','big'),False,False,0);box.pack_start(label(str(exc),'detail'),False,False,0);box.pack_start(label('Detalii tehnice sunt scrise în jurnalul aplicației.','dim'),False,False,0);win.add(box);win.show_all();win.present()

    def change_language(self,language):
        old=self.props.active_window
        if not old or language not in TEXT:return
        old.flush_local();old.save_preference('language',language);self.hold()
        try:
            new=NexusWindow(self,language,'dashboard')
            new.show_all();old.closed=True;old.destroy();new.present()
        except Exception:
            traceback.print_exc();old.language_combo.set_active_id(old.language);old.fetch()
        finally:self.release()

if __name__=='__main__':App().run(None)
