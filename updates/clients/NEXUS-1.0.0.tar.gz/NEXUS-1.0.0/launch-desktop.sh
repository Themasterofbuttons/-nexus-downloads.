#!/usr/bin/env bash
cd "$(dirname "$0")"
mkdir -p "$HOME/.local/state/nexus"
exec /usr/bin/python3 desktop_app.py "$@" >> "$HOME/.local/state/nexus/desktop.log" 2>&1
