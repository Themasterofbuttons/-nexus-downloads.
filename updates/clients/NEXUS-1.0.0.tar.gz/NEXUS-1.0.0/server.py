#!/usr/bin/env python3
"""Local hardware monitor. Open http://localhost:8765; use --host 0.0.0.0 for LAN access."""
import argparse
import json
import math
import os
import platform
import re
import shutil
import subprocess
import time
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

import psutil

ROOT = Path(__file__).resolve().parent
_last_energy = {}


def command(args, timeout=1.5):
    try:
        return subprocess.run(args, capture_output=True, text=True, timeout=timeout, check=False).stdout.strip()
    except (OSError, subprocess.TimeoutExpired):
        return ""


def power_watts():
    """Estimate whole-system power from Linux RAPL energy counters when available."""
    global _last_energy
    counters = {}
    paths = sorted(Path('/sys/class/powercap').glob('**/energy_uj'), key=lambda p: len(p.parts))
    # RAPL exposes package counters alongside child counters (cores, uncore,
    # graphics). Summing both counts the same energy twice.
    selected = []
    for path in paths:
        if 'dram' in str(path).lower():
            continue
        if any(parent.parent in path.parents for parent in selected):
            continue
        selected.append(path)
    for path in selected:
        try:
            energy = int(path.read_text().strip())
            try:
                maximum = int(path.with_name('max_energy_range_uj').read_text().strip())
            except (OSError, ValueError):
                maximum = None
            counters[str(path)] = (energy, maximum)
        except (OSError, ValueError):
            continue
    now = time.monotonic()
    result = None
    if counters and _last_energy:
        old_counters, old_time = _last_energy
        elapsed = now - old_time
        delta = 0
        for key, (energy, maximum) in counters.items():
            previous = old_counters.get(key)
            if previous is None:
                continue
            old_energy, old_maximum = previous
            difference = energy - old_energy
            wrap = maximum or old_maximum
            if difference < 0:
                if wrap:
                    difference += wrap
                else:
                    continue
            delta += difference
        if elapsed > 0 and delta > 0:
            result = round(delta / 1_000_000 / elapsed, 1)
    _last_energy = (counters, now) if counters else {}
    # On laptops, battery power provides a useful alternative (positive means discharge).
    batt = psutil.sensors_battery()
    if result is None and batt and batt.power_plugged is False:
        for p in Path('/sys/class/power_supply').glob('**/power_now'):
            try:
                result = round(int(p.read_text().strip()) / 1_000_000, 1)
                break
            except (OSError, ValueError):
                pass
        if result is None:
            for current_path in Path('/sys/class/power_supply').glob('**/current_now'):
                try:
                    current_ua = abs(int(current_path.read_text().strip()))
                    voltage_uv = int(current_path.with_name('voltage_now').read_text().strip())
                    if current_ua and voltage_uv:
                        result = round(current_ua * voltage_uv / 1_000_000_000_000, 1)
                        break
                except (OSError, ValueError):
                    continue
    return result


def temperatures():
    out = []
    try:
        for chip, entries in psutil.sensors_temperatures(fahrenheit=False).items():
            for item in entries:
                if item.current is None or not math.isfinite(item.current) or not -80 <= item.current <= 250:
                    continue
                # Some hwmon drivers use large numeric sentinels for missing limits.
                high = item.high if item.high is not None and math.isfinite(item.high) and 0 < item.high <= 250 else None
                critical = item.critical if item.critical is not None and math.isfinite(item.critical) and 0 < item.critical <= 250 else None
                out.append({'name': item.label or chip, 'chip': chip, 'c': round(item.current, 1), 'high': high, 'critical': critical})
    except (AttributeError, OSError):
        pass
    return out


def fans():
    out = []
    try:
        for chip, entries in psutil.sensors_fans().items():
            for item in entries:
                if item.current is not None and math.isfinite(item.current) and 0 <= item.current <= 200_000:
                    out.append({'name': item.label or chip, 'rpm': int(item.current)})
    except (AttributeError, OSError):
        pass
    return out


def wireless():
    wifi_available = bool(shutil.which('iwgetid') or shutil.which('nmcli'))
    ssid = command(['iwgetid', '-r']) if shutil.which('iwgetid') else ''
    if not ssid and shutil.which('nmcli'):
        status = command(['nmcli', '-t', '-f', 'ACTIVE,SSID', 'dev', 'wifi'])
        for row in status.splitlines():
            if row.startswith('yes:'):
                ssid = row[4:]
                break
    bt = None
    bluetooth_available = bool(shutil.which('bluetoothctl'))
    if bluetooth_available:
        info = command(['bluetoothctl', 'show'])
        match = re.search(r'Powered:\s*(yes|no)', info, re.I)
        if match:
            bt = match.group(1).lower() == 'yes'
    return {'wifi': ssid or None, 'wifi_available': wifi_available,
            'bluetooth': bt, 'bluetooth_available': bluetooth_available}


def connection_count(kind):
    try:
        return len(psutil.net_connections(kind=kind))
    except (psutil.Error, OSError):
        # Unknown is different from a measured zero when socket inspection is restricted.
        return None


def snapshot():
    vm = psutil.virtual_memory()
    swap = psutil.swap_memory()
    disks = []
    seen_mounts = set()
    seen_filesystems = set()
    for part in psutil.disk_partitions(all=False):
        if part.mountpoint in seen_mounts or not os.path.exists(part.mountpoint):
            continue
        seen_mounts.add(part.mountpoint)
        try:
            usage = psutil.disk_usage(part.mountpoint)
            identity = (part.device or part.mountpoint, part.fstype, usage.total)
            if identity in seen_filesystems:
                continue
            seen_filesystems.add(identity)
            disks.append({'mount': part.mountpoint, 'device': part.device, 'total': usage.total, 'used': usage.used, 'percent': usage.percent})
        except OSError:
            pass
    interfaces = []
    try:
        stats = psutil.net_if_stats()
    except (psutil.Error, OSError):
        stats = {}
    try:
        counters = psutil.net_io_counters(pernic=True) or {}
    except (psutil.Error, OSError):
        counters = {}
    try:
        addrs = psutil.net_if_addrs()
    except (psutil.Error, OSError):
        addrs = {}
    for name, stat in stats.items():
        if name == 'lo':
            continue
        ips = [a.address for a in addrs.get(name, []) if a.family == getattr(__import__('socket'), 'AF_INET')]
        c = counters.get(name)
        interfaces.append({'name': name, 'up': stat.isup, 'speed': stat.speed, 'ip': ips[0] if ips else None,
                           'sent': c.bytes_sent if c else 0, 'recv': c.bytes_recv if c else 0})
    battery = psutil.sensors_battery()
    cpu_freq = psutil.cpu_freq()
    uptime_s = max(0, int(time.time() - psutil.boot_time()))
    tcp_count = connection_count('tcp')
    udp_count = connection_count('udp')
    return {
        'time': time.time(), 'cpu': psutil.cpu_percent(interval=None), 'cores': psutil.cpu_percent(interval=None, percpu=True),
        'host': {'name': platform.node() or 'Dispozitiv local', 'system': platform.system(), 'release': platform.release(),
                 'uptime_s': uptime_s, 'processes': len(psutil.pids()),
                 'cpu_mhz': round(cpu_freq.current, 0) if cpu_freq else None},
        'ram': {'total': vm.total, 'used': vm.used, 'available': vm.available, 'percent': vm.percent},
        'swap': {'total': swap.total, 'used': swap.used, 'percent': swap.percent}, 'disks': disks,
        'power_w': power_watts(), 'fans': fans(), 'temps': temperatures(),
        'battery': ({'percent': battery.percent, 'plugged': battery.power_plugged, 'seconds': battery.secsleft} if battery else None),
        'interfaces': interfaces, 'wireless': wireless(),
        'connections': {'tcp': tcp_count, 'udp': udp_count}
    }


class Handler(SimpleHTTPRequestHandler):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, directory=str(ROOT), **kwargs)

    def do_GET(self):
        if self.path.split('?', 1)[0] == '/api/stats':
            try:
                body = json.dumps(snapshot()).encode()
                self.send_response(200)
                self.send_header('Content-Type', 'application/json; charset=utf-8')
                self.send_header('Cache-Control', 'no-store')
                self.send_header('Content-Length', str(len(body)))
                self.end_headers()
                self.wfile.write(body)
            except Exception as exc:
                body = json.dumps({'error': str(exc)}).encode()
                self.send_error(500, body.decode())
            return
        if self.path == '/':
            self.path = '/static/index.html'
        super().do_GET()

    def log_message(self, fmt, *args):
        print('[%s] %s' % (self.log_date_time_string(), fmt % args))


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='Live system dashboard')
    parser.add_argument('--host', default='127.0.0.1', help='Use 0.0.0.0 to open on your Wi-Fi network')
    parser.add_argument('--port', type=int, default=8765)
    args = parser.parse_args()
    psutil.cpu_percent(interval=None)
    server = ThreadingHTTPServer((args.host, args.port), Handler)
    print(f'Dashboard available at http://localhost:{args.port}')
    if args.host == '0.0.0.0':
        print('LAN access: open this computer IP and port from another device on the same Wi-Fi.')
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print('\nStopping monitor.')
